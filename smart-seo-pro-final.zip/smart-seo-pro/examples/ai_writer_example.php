<?php
/**
 * Enhanced AI Writer Example for Smart SEO Pro
 * Based on your original UptownTrading example but improved with our 6-agent system
 * 
 * @since 1.0.0
 */

// Include the Smart SEO Pro content generator
require_once __DIR__ . '/../includes/modules/content-generator/class-content-generator.php';
require_once __DIR__ . '/../includes/modules/content-generator/agents/class-keyword-finder.php';
require_once __DIR__ . '/../includes/modules/content-generator/agents/class-outline-generator.php';
require_once __DIR__ . '/../includes/modules/content-generator/agents/class-ai-writer.php';
require_once __DIR__ . '/../includes/modules/content-generator/agents/class-optimizer.php';
require_once __DIR__ . '/../includes/modules/content-generator/agents/class-media-generator.php';
require_once __DIR__ . '/../includes/modules/content-generator/agents/class-publisher.php';

use SmartSeoPro\ContentGenerator\Content_Generator;

// Configuration - Set your API keys
$config = [
    'openai_api_key' => 'sk-xxx', // 🔑 Your OpenAI API key
    'language' => 'th', // Thai language
    'content_type' => 'blog_post',
];

// Your business information
$business_info = [
    'name' => 'UptownTrading',
    'products' => ['บ้องแก้ว', 'กระดาษโรล', 'อุปกรณ์สูบ'],
    'channels' => [
        'website' => 'https://uptowntrading.co',
        'shopee' => 'https://shopee.co.th/uptowntrading',
        'lazada' => 'https://www.lazada.co.th/shop/uptowntrading',
        'how_to_order' => 'https://uptowntrading.co/how-to-order'
    ]
];

// Target keyword and content details
$primary_keyword = 'ขายบ้องแก้ว ขายส่ง';
$target_audience = 'เจ้าของร้าน/ผู้เริ่มต้นธุรกิจ';

echo "<h1>🚀 Smart SEO Pro - Enhanced AI Content Generator</h1>";
echo "<p>Generating SEO-optimized content for: <strong>{$primary_keyword}</strong></p>";

try {
    // Initialize the content generator
    $generator = new Content_Generator();

    echo "<h2>🔍 Step 1: Finding Keywords...</h2>";
    
    // Agent 1: Find keywords
    $keyword_finder = $generator->get_agent('keyword_finder');
    $keywords = $keyword_finder->find_keywords($primary_keyword);
    
    echo "<div style='background: #f0f8ff; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<h3>Keywords Found:</h3>";
    echo "<p><strong>Primary:</strong> {$keywords['primary']}</p>";
    echo "<p><strong>LSI Keywords:</strong> " . implode(', ', array_slice($keywords['lsi'], 0, 5)) . "</p>";
    echo "<p><strong>Long-tail:</strong> " . implode(', ', array_slice($keywords['long_tail'], 0, 3)) . "</p>";
    echo "</div>";

    echo "<h2>📋 Step 2: Generating Outline...</h2>";
    
    // Agent 2: Generate outline with Thai-specific context
    $outline_generator = $generator->get_agent('outline_generator');
    $outline = $outline_generator->generate_outline($primary_keyword, $keywords, 'blog_post', 'th');
    
    echo "<div style='background: #f0fff0; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<h3>Content Outline:</h3>";
    echo "<p><strong>Title:</strong> {$outline['title']}</p>";
    echo "<p><strong>Meta Description:</strong> {$outline['meta_description']}</p>";
    echo "<p><strong>Sections:</strong> " . count($outline['sections']) . " main sections</p>";
    echo "<p><strong>Target Word Count:</strong> {$outline['word_count_target']} words</p>";
    echo "</div>";

    echo "<h2>✍️ Step 3: Writing Content...</h2>";
    
    // Agent 3: Generate content with business context
    $ai_writer = $generator->get_agent('ai_writer');
    
    // Enhance the outline with business-specific information
    $enhanced_outline = enhance_outline_for_business($outline, $business_info, $target_audience);
    
    $content = $ai_writer->generate_content($primary_keyword, $enhanced_outline, $keywords, 'th');
    
    echo "<div style='background: #fff8f0; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<h3>Content Generated:</h3>";
    echo "<p><strong>Title:</strong> {$content['title']}</p>";
    echo "<p><strong>Word Count:</strong> " . str_word_count(strip_tags($content['full_html'])) . " words</p>";
    echo "<details><summary>View Content Preview</summary>";
    echo "<div style='max-height: 300px; overflow-y: auto; border: 1px solid #ddd; padding: 10px; margin: 10px 0;'>";
    echo $content['full_html'];
    echo "</div></details>";
    echo "</div>";

    echo "<h2>🔧 Step 4: Optimizing Content...</h2>";
    
    // Agent 4: Optimize content
    $optimizer = $generator->get_agent('optimizer');
    $optimized_content = $optimizer->optimize_content($content, $primary_keyword, $keywords);
    
    echo "<div style='background: #f8f0ff; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<h3>SEO Optimization Results:</h3>";
    echo "<p><strong>SEO Score:</strong> {$optimized_content['seo_score']}/100</p>";
    echo "<p><strong>Keyword Density:</strong> " . round($optimized_content['keyword_analysis']['primary_keyword']['density'], 2) . "%</p>";
    echo "<p><strong>Readability Score:</strong> {$optimized_content['readability']['score']} ({$optimized_content['readability']['level']})</p>";
    echo "<p><strong>URL Slug:</strong> {$optimized_content['url_slug']}</p>";
    
    if (!empty($optimized_content['seo_recommendations'])) {
        echo "<h4>💡 SEO Recommendations:</h4><ul>";
        foreach (array_slice($optimized_content['seo_recommendations'], 0, 3) as $rec) {
            echo "<li>{$rec['message']}</li>";
        }
        echo "</ul>";
    }
    echo "</div>";

    echo "<h2>🖼️ Step 5: Generating Media...</h2>";
    
    // Agent 5: Generate media (Note: This requires OpenAI API with image generation)
    $media_generator = $generator->get_agent('media_generator');
    
    echo "<div style='background: #f0f8f8; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<h3>Media Generation:</h3>";
    echo "<p>🎨 Featured image prompt: Professional image showcasing {$primary_keyword}</p>";
    echo "<p>📊 Infographic: Key benefits and product information</p>";
    echo "<p>💡 <em>Note: Media generation requires OpenAI API key with image generation enabled</em></p>";
    echo "</div>";

    echo "<h2>📤 Step 6: Preparing for Publishing...</h2>";
    
    // Agent 6: Prepare for publishing
    $publisher = $generator->get_agent('publisher');
    $publish_data = $publisher->prepare_for_publishing($optimized_content, []);
    
    echo "<div style='background: #f0f0f8; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<h3>Publishing Checklist:</h3>";
    foreach ($publish_data['publishing_checklist'] as $item) {
        $icon = $item['status'] === 'good' ? '✅' : ($item['status'] === 'warning' ? '⚠️' : '❌');
        echo "<p>{$icon} <strong>{$item['item']}:</strong> {$item['message']}</p>";
    }
    echo "</div>";

    echo "<h2>🎉 Final Output</h2>";
    
    // Display the final optimized content
    echo "<div style='background: #ffffff; border: 2px solid #2271b1; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
    echo "<h3>📝 Ready-to-Publish Content</h3>";
    echo "<p><strong>Title:</strong> {$optimized_content['title']}</p>";
    echo "<p><strong>Meta Description:</strong> {$optimized_content['meta_description']}</p>";
    echo "<p><strong>URL Slug:</strong> {$optimized_content['url_slug']}</p>";
    echo "<hr>";
    echo "<h4>Content Body:</h4>";
    echo "<div style='border: 1px solid #ddd; padding: 15px; max-height: 400px; overflow-y: auto;'>";
    echo $optimized_content['full_html'];
    echo "</div>";
    echo "</div>";

    // Generate schema markup
    if (!empty($publish_data['schema_markup'])) {
        echo "<h3>🔧 Schema Markup (JSON-LD)</h3>";
        echo "<pre style='background: #f5f5f5; padding: 15px; border-radius: 8px; overflow-x: auto;'>";
        echo json_encode($publish_data['schema_markup'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        echo "</pre>";
    }

} catch (Exception $e) {
    echo "<div style='background: #ffebee; color: #c62828; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<h3>❌ Error:</h3>";
    echo "<p>{$e->getMessage()}</p>";
    echo "</div>";
}

/**
 * Enhance outline with business-specific information
 */
function enhance_outline_for_business($outline, $business_info, $target_audience) {
    // Add business context to the outline
    $enhanced_outline = $outline;
    
    // Add business information to introduction notes
    if (isset($enhanced_outline['introduction']['notes'])) {
        $enhanced_outline['introduction']['notes'][] = "แนะนำ {$business_info['name']} เป็นผู้จำหน่ายชั้นนำ";
        $enhanced_outline['introduction']['notes'][] = "เน้นกลุ่มเป้าหมาย: {$target_audience}";
    }
    
    // Add business channels to conclusion
    if (isset($enhanced_outline['conclusion']['notes'])) {
        $enhanced_outline['conclusion']['notes'][] = "แนะนำช่องทางการสั่งซื้อ: เว็บไซต์หลัก, Shopee, Lazada";
        $enhanced_outline['conclusion']['notes'][] = "เพิ่ม Call-to-Action ที่ชัดเจน";
    }
    
    // Add business-specific sections
    $business_section = [
        'heading' => 'ทำไมต้องเลือก ' . $business_info['name'],
        'level' => 2,
        'notes' => [
            'เน้นประสบการณ์และความน่าเชื่อถือ',
            'แนะนำผลิตภัณฑ์หลัก: ' . implode(', ', $business_info['products']),
            'ข้อได้เปรียบในการขายส่ง'
        ]
    ];
    
    $channels_section = [
        'heading' => 'ช่องทางการสั่งซื้อที่สะดวก',
        'level' => 2,
        'notes' => [
            'เว็บไซต์หลัก: ' . $business_info['channels']['website'],
            'Shopee: สะดวกและมีโปรโมชั่น',
            'Lazada: จัดส่งรวดเร็ว',
            'วิธีการสั่งซื้อ: ' . $business_info['channels']['how_to_order']
        ]
    ];
    
    // Insert business sections before conclusion
    array_splice($enhanced_outline['sections'], -1, 0, [$business_section, $channels_section]);
    
    return $enhanced_outline;
}

echo "<style>
body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; line-height: 1.6; margin: 20px; }
h1, h2, h3 { color: #2271b1; }
pre { font-size: 12px; }
details summary { cursor: pointer; font-weight: bold; }
</style>";
?>