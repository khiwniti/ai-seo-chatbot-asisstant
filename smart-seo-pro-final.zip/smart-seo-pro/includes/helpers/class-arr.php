<?php
/**
 * Array helper.
 *
 * @package SmartSeoPro
 */

namespace RankMath\Helpers;

/**
 * Array helper class.
 */
class Arr {

	/**
	 * Get value from array using dot notation.
	 *
	 * @param array  $array   Array to search.
	 * @param string $key     Key in dot notation.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public static function get( $array, $key, $default = null ) {
		if ( is_null( $key ) ) {
			return $array;
		}

		if ( isset( $array[ $key ] ) ) {
			return $array[ $key ];
		}

		foreach ( explode( '.', $key ) as $segment ) {
			if ( ! is_array( $array ) || ! array_key_exists( $segment, $array ) ) {
				return $default;
			}

			$array = $array[ $segment ];
		}

		return $array;
	}

	/**
	 * Set value in array using dot notation.
	 *
	 * @param array  $array Array to modify.
	 * @param string $key   Key in dot notation.
	 * @param mixed  $value Value to set.
	 * @return array
	 */
	public static function set( &$array, $key, $value ) {
		if ( is_null( $key ) ) {
			return $array = $value;
		}

		$keys = explode( '.', $key );

		while ( count( $keys ) > 1 ) {
			$key = array_shift( $keys );

			if ( ! isset( $array[ $key ] ) || ! is_array( $array[ $key ] ) ) {
				$array[ $key ] = [];
			}

			$array = &$array[ $key ];
		}

		$array[ array_shift( $keys ) ] = $value;

		return $array;
	}

	/**
	 * Check if array has key using dot notation.
	 *
	 * @param array  $array Array to check.
	 * @param string $key   Key in dot notation.
	 * @return bool
	 */
	public static function has( $array, $key ) {
		if ( is_null( $key ) ) {
			return false;
		}

		if ( isset( $array[ $key ] ) ) {
			return true;
		}

		foreach ( explode( '.', $key ) as $segment ) {
			if ( ! is_array( $array ) || ! array_key_exists( $segment, $array ) ) {
				return false;
			}

			$array = $array[ $segment ];
		}

		return true;
	}

	/**
	 * Flatten array.
	 *
	 * @param array  $array Array to flatten.
	 * @param string $prefix Prefix for keys.
	 * @return array
	 */
	public static function flatten( $array, $prefix = '' ) {
		$result = [];

		foreach ( $array as $key => $value ) {
			$new_key = $prefix . $key;

			if ( is_array( $value ) ) {
				$result = array_merge( $result, self::flatten( $value, $new_key . '.' ) );
			} else {
				$result[ $new_key ] = $value;
			}
		}

		return $result;
	}
}