<?php
/**
 * Ajax trait.
 *
 * @package SmartSeoPro
 */

namespace RankMath\Traits;

/**
 * Ajax trait.
 */
trait Ajax {

	/**
	 * Add AJAX action.
	 *
	 * @param string $action   Action name.
	 * @param string $callback Callback method.
	 * @param bool   $nopriv   Whether to add nopriv action.
	 */
	public function ajax( $action, $callback = '', $nopriv = false ) {
		$callback = empty( $callback ) ? $action : $callback;
		
		if ( function_exists( 'add_action' ) ) {
			add_action( "wp_ajax_{$action}", [ $this, $callback ] );
			
			if ( $nopriv ) {
				add_action( "wp_ajax_nopriv_{$action}", [ $this, $callback ] );
			}
		}
	}

	/**
	 * Verify nonce.
	 *
	 * @param string $action Action name.
	 * @param string $nonce  Nonce value.
	 * @return bool
	 */
	public function verify_nonce( $action, $nonce = '' ) {
		if ( ! function_exists( 'wp_verify_nonce' ) ) {
			return true; // Mock verification
		}
		
		$nonce = empty( $nonce ) ? filter_input( INPUT_POST, 'security', FILTER_SANITIZE_STRING ) : $nonce;
		return wp_verify_nonce( $nonce, $action );
	}

	/**
	 * Send JSON success response.
	 *
	 * @param mixed $data Response data.
	 */
	public function success( $data = null ) {
		if ( function_exists( 'wp_send_json_success' ) ) {
			wp_send_json_success( $data );
		} else {
			echo json_encode( [ 'success' => true, 'data' => $data ] );
			exit;
		}
	}

	/**
	 * Send JSON error response.
	 *
	 * @param mixed $data Error data.
	 */
	public function error( $data = null ) {
		if ( function_exists( 'wp_send_json_error' ) ) {
			wp_send_json_error( $data );
		} else {
			echo json_encode( [ 'success' => false, 'data' => $data ] );
			exit;
		}
	}
}