<?php
/**
 * The Content Generator module.
 *
 * @since      1.0.0
 * @package    SmartSeo
 * @subpackage SmartSeoPro
 * @author     Smart SEO Team <support@smartseo.dev>
 */

namespace RankMathPro\ContentGenerator;

// Use WordPress hooks directly instead of traits for compatibility
defined( 'ABSPATH' ) || exit;

/**
 * Content_Generator class.
 */
class Content_Generator {

	/**
	 * The agents instances.
	 *
	 * @var array
	 */
	private $agents = [];

	/**
	 * Class constructor.
	 */
	public function __construct() {
		$this->init_agents();
		$this->init_hooks();
	}

	/**
	 * Initialize all content generation agents.
	 */
	private function init_agents() {
		$this->agents = [
			'keyword_finder'  => new Agents\Keyword_Finder(),
			'outline_generator' => new Agents\Outline_Generator(),
			'ai_writer'       => new Agents\AI_Writer(),
			'optimizer'       => new Agents\Optimizer(),
			'media_generator' => new Agents\Media_Generator(),
			'publisher'       => new Agents\Publisher(),
		];
	}

	/**
	 * Initialize hooks.
	 */
	private function init_hooks() {
		add_action( 'wp_ajax_smart_seo_generate_content', array( $this, 'ajax_generate_content' ) );
		add_action( 'wp_ajax_smart_seo_get_keywords', array( $this, 'ajax_get_keywords' ) );
		add_action( 'wp_ajax_smart_seo_generate_outline', array( $this, 'ajax_generate_outline' ) );
		add_action( 'wp_ajax_smart_seo_generate_media', array( $this, 'ajax_generate_media' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
		add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
	}

	/**
	 * Enqueue frontend scripts.
	 */
	public function enqueue_scripts() {
		if ( ! is_admin() ) {
			return;
		}

		wp_enqueue_script(
			'smart-seo-content-generator',
			SMART_SEO_PRO_URL . 'includes/modules/content-generator/assets/js/content-generator.js',
			[ 'jquery' ],
			SMART_SEO_PRO_VERSION,
			true
		);

		wp_localize_script(
			'smart-seo-content-generator',
			'smartSeoContentGenerator',
			[
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'smart_seo_content_generator' ),
			]
		);
	}

	/**
	 * Enqueue admin scripts.
	 */
	public function enqueue_admin_scripts() {
		$screen = get_current_screen();
		if ( ! $screen || ! in_array( $screen->id, [ 'post', 'page' ], true ) ) {
			return;
		}

		wp_enqueue_style(
			'smart-seo-content-generator',
			SMART_SEO_PRO_URL . 'includes/modules/content-generator/assets/css/content-generator.css',
			[],
			SMART_SEO_PRO_VERSION
		);

		$this->enqueue_scripts();
	}

	/**
	 * Add admin menu for content generator.
	 */
	public function add_admin_menu() {
		add_submenu_page(
			'tools.php',
			'Smart SEO Content Generator',
			'Content Generator',
			'edit_posts',
			'smart-seo-content-generator',
			array( $this, 'admin_page' )
		);
	}

	/**
	 * Render admin page.
	 */
	public function admin_page() {
		?>
		<div class="wrap">
			<h1>Smart SEO Content Generator</h1>
			<div id="smart-seo-content-generator-admin">
				<!-- Content generator interface will be loaded here via JavaScript -->
			</div>
		</div>
		<?php
	}

	/**
	 * AJAX handler for full content generation.
	 */
	public function ajax_generate_content() {
		check_ajax_referer( 'smart_seo_content_generator', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( 'Unauthorized' );
		}

		$keyword = sanitize_text_field( $_POST['keyword'] ?? '' );
		$content_type = sanitize_text_field( $_POST['content_type'] ?? 'blog_post' );
		$language = sanitize_text_field( $_POST['language'] ?? 'en' );

		if ( empty( $keyword ) ) {
			wp_send_json_error( 'Keyword is required' );
		}

		try {
			// Step 1: Find keywords
			$keywords = $this->agents['keyword_finder']->find_keywords( $keyword );

			// Step 2: Generate outline
			$outline = $this->agents['outline_generator']->generate_outline( $keyword, $keywords, $content_type, $language );

			// Step 3: Generate content
			$content = $this->agents['ai_writer']->generate_content( $keyword, $outline, $keywords, $language );

			// Step 4: Optimize content
			$optimized_content = $this->agents['optimizer']->optimize_content( $content, $keyword, $keywords );

			// Step 5: Generate media (optional)
			$media = $this->agents['media_generator']->generate_media( $keyword, $content['title'] ?? '' );

			// Step 6: Prepare for publishing
			$publish_data = $this->agents['publisher']->prepare_for_publishing( $optimized_content, $media );

			wp_send_json_success( [
				'keywords' => $keywords,
				'outline'  => $outline,
				'content'  => $optimized_content,
				'media'    => $media,
				'publish_data' => $publish_data,
			] );

		} catch ( Exception $e ) {
			wp_send_json_error( 'Content generation failed: ' . $e->getMessage() );
		}
	}

	/**
	 * AJAX handler for keyword research.
	 */
	public function ajax_get_keywords() {
		check_ajax_referer( 'smart_seo_content_generator', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( 'Unauthorized' );
		}

		$keyword = sanitize_text_field( $_POST['keyword'] ?? '' );

		if ( empty( $keyword ) ) {
			wp_send_json_error( 'Keyword is required' );
		}

		try {
			$keywords = $this->agents['keyword_finder']->find_keywords( $keyword );
			wp_send_json_success( $keywords );
		} catch ( Exception $e ) {
			wp_send_json_error( 'Keyword research failed: ' . $e->getMessage() );
		}
	}

	/**
	 * AJAX handler for outline generation.
	 */
	public function ajax_generate_outline() {
		check_ajax_referer( 'smart_seo_content_generator', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_die( 'Unauthorized' );
		}

		$keyword = sanitize_text_field( $_POST['keyword'] ?? '' );
		$keywords = json_decode( stripslashes( $_POST['keywords'] ?? '[]' ), true );
		$content_type = sanitize_text_field( $_POST['content_type'] ?? 'blog_post' );
		$language = sanitize_text_field( $_POST['language'] ?? 'en' );

		if ( empty( $keyword ) ) {
			wp_send_json_error( 'Keyword is required' );
		}

		try {
			$outline = $this->agents['outline_generator']->generate_outline( $keyword, $keywords, $content_type, $language );
			wp_send_json_success( $outline );
		} catch ( Exception $e ) {
			wp_send_json_error( 'Outline generation failed: ' . $e->getMessage() );
		}
	}

	/**
	 * AJAX handler for media generation.
	 */
	public function ajax_generate_media() {
		check_ajax_referer( 'smart_seo_content_generator', 'nonce' );

		if ( ! current_user_can( 'upload_files' ) ) {
			wp_die( 'Unauthorized' );
		}

		$keyword = sanitize_text_field( $_POST['keyword'] ?? '' );
		$title = sanitize_text_field( $_POST['title'] ?? '' );

		if ( empty( $keyword ) ) {
			wp_send_json_error( 'Keyword is required' );
		}

		try {
			$media = $this->agents['media_generator']->generate_media( $keyword, $title );
			wp_send_json_success( $media );
		} catch ( Exception $e ) {
			wp_send_json_error( 'Media generation failed: ' . $e->getMessage() );
		}
	}

	/**
	 * Get agent instance.
	 *
	 * @param string $agent_name Agent name.
	 * @return object|null
	 */
	public function get_agent( $agent_name ) {
		return $this->agents[ $agent_name ] ?? null;
	}
}