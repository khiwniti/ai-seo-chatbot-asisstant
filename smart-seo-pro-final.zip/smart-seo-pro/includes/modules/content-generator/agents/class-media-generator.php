<?php
/**
 * Media Generator Agent.
 *
 * @since      1.0.0
 * @package    SmartSeo
 * @subpackage SmartSeoPro\ContentGenerator\Agents
 * @author     Smart SEO Team <support@smartseo.dev>
 */

namespace RankMathPro\ContentGenerator\Agents;

defined( 'ABSPATH' ) || exit;

/**
 * Media_Generator class.
 */
class Media_Generator {

	/**
	 * Generate media content for the article.
	 *
	 * @param string $keyword Primary keyword.
	 * @param string $title Article title.
	 * @return array
	 */
	public function generate_media( $keyword, $title = '' ) {
		$media = [
			'featured_image' => null,
			'content_images' => [],
			'alt_texts' => [],
			'captions' => [],
		];

		try {
			// Generate featured image
			$featured_image = $this->generate_featured_image( $keyword, $title );
			if ( $featured_image ) {
				$media['featured_image'] = $featured_image;
			}

			// Generate additional content images
			$content_images = $this->generate_content_images( $keyword, $title );
			if ( ! empty( $content_images ) ) {
				$media['content_images'] = $content_images;
			}

		} catch ( Exception $e ) {
			error_log( 'Media generation failed: ' . $e->getMessage() );
		}

		return $media;
	}

	/**
	 * Generate featured image using OpenAI DALL-E.
	 *
	 * @param string $keyword Primary keyword.
	 * @param string $title Article title.
	 * @return array|null
	 */
	private function generate_featured_image( $keyword, $title ) {
		$openai_api_key = get_option( 'smart_seo_openai_api_key', '' );

		if ( empty( $openai_api_key ) ) {
			return null;
		}

		$prompt = $this->build_image_prompt( $keyword, $title, 'featured' );
		
		$url = 'https://api.openai.com/v1/images/generations';

		$body = json_encode( [
			'model' => 'dall-e-3',
			'prompt' => $prompt,
			'n' => 1,
			'size' => '1792x1024',
			'quality' => 'standard',
			'response_format' => 'url',
		] );

		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Authorization: Bearer ' . $openai_api_key,
			'Content-Type: application/json',
		]);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);
		
		$response = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		if ($response === false || $http_code !== 200) {
			return null;
		}

		$data = json_decode($response, true);

		if ( empty( $data['data'][0]['url'] ) ) {
			return null;
		}

		$image_url = $data['data'][0]['url'];
		$uploaded_image = $this->upload_image_to_media_library( $image_url, $keyword, 'featured' );

		if ( $uploaded_image ) {
			return [
				'id' => $uploaded_image['id'],
				'url' => $uploaded_image['url'],
				'alt_text' => $this->generate_alt_text( $keyword, 'featured image' ),
				'caption' => $this->generate_caption( $keyword, $title ),
				'filename' => $uploaded_image['filename'],
			];
		}

		return null;
	}

	/**
	 * Generate content images.
	 *
	 * @param string $keyword Primary keyword.
	 * @param string $title Article title.
	 * @return array
	 */
	private function generate_content_images( $keyword, $title ) {
		$openai_api_key = get_option( 'smart_seo_openai_api_key', '' );

		if ( empty( $openai_api_key ) ) {
			return [];
		}

		$images = [];
		$image_types = [ 'infographic', 'illustration', 'diagram' ];

		foreach ( $image_types as $type ) {
			$prompt = $this->build_image_prompt( $keyword, $title, $type );
			
			$url = 'https://api.openai.com/v1/images/generations';

			$body = json_encode( [
				'model' => 'dall-e-3',
				'prompt' => $prompt,
				'n' => 1,
				'size' => '1024x1024',
				'quality' => 'standard',
				'response_format' => 'url',
			] );

			$ch = curl_init($url);
			curl_setopt($ch, CURLOPT_HTTPHEADER, [
				'Authorization: Bearer ' . $openai_api_key,
				'Content-Type: application/json',
			]);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_TIMEOUT, 60);
			
			$response = curl_exec($ch);
			$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
			curl_close($ch);

			if ($response === false || $http_code !== 200) {
				continue;
			}

			$data = json_decode($response, true);

			if ( empty( $data['data'][0]['url'] ) ) {
				continue;
			}

			$image_url = $data['data'][0]['url'];
			$uploaded_image = $this->upload_image_to_media_library( $image_url, $keyword, $type );

			if ( $uploaded_image ) {
				$images[] = [
					'id' => $uploaded_image['id'],
					'url' => $uploaded_image['url'],
					'alt_text' => $this->generate_alt_text( $keyword, $type ),
					'caption' => $this->generate_caption( $keyword, $title, $type ),
					'filename' => $uploaded_image['filename'],
					'type' => $type,
				];
			}

			// Add delay to avoid rate limiting
			sleep( 2 );
		}

		return $images;
	}

	/**
	 * Build image generation prompt.
	 *
	 * @param string $keyword Primary keyword.
	 * @param string $title Article title.
	 * @param string $type Image type.
	 * @return string
	 */
	private function build_image_prompt( $keyword, $title, $type ) {
		$base_prompt = "Create a professional, high-quality image related to '{$keyword}'";

		switch ( $type ) {
			case 'featured':
				$prompt = "{$base_prompt}. This is a featured image for an article titled '{$title}'. Make it visually appealing, modern, and suitable for a blog header. Use vibrant colors and clean design.";
				break;

			case 'infographic':
				$prompt = "{$base_prompt}. Create an infographic-style image with charts, icons, or data visualization elements. Use a clean, professional design with clear typography.";
				break;

			case 'illustration':
				$prompt = "{$base_prompt}. Create a detailed illustration that explains or demonstrates concepts related to the topic. Use a modern, flat design style with appropriate colors.";
				break;

			case 'diagram':
				$prompt = "{$base_prompt}. Create a diagram or flowchart that shows processes, relationships, or structures related to the topic. Use clear lines, shapes, and labels.";
				break;

			default:
				$prompt = "{$base_prompt}. Create a professional, relevant image that supports the content about this topic.";
		}

		$prompt .= " Avoid any text in the image. Use a 16:9 aspect ratio for featured images or square format for content images. Ensure the image is suitable for web use and SEO-friendly.";

		return $prompt;
	}

	/**
	 * Upload image to WordPress media library.
	 *
	 * @param string $image_url Remote image URL.
	 * @param string $keyword Keyword for filename.
	 * @param string $type Image type.
	 * @return array|null
	 */
	private function upload_image_to_media_library( $image_url, $keyword, $type ) {
		if ( ! function_exists( 'media_handle_sideload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/media.php';
			require_once ABSPATH . 'wp-admin/includes/file.php';
			require_once ABSPATH . 'wp-admin/includes/image.php';
		}

		// Download the image
		$response = wp_remote_get( $image_url, [
			'timeout' => 60,
		] );

		if ( is_wp_error( $response ) ) {
			return null;
		}

		$image_data = wp_remote_retrieve_body( $response );
		$content_type = wp_remote_retrieve_header( $response, 'content-type' );

		// Determine file extension
		$extension = 'png';
		if ( strpos( $content_type, 'jpeg' ) !== false ) {
			$extension = 'jpg';
		} elseif ( strpos( $content_type, 'webp' ) !== false ) {
			$extension = 'webp';
		}

		// Create filename
		$filename = $this->create_seo_filename( $keyword, $type, $extension );

		// Create temporary file
		$temp_file = wp_tempnam( $filename );
		file_put_contents( $temp_file, $image_data );

		// Prepare file array for media_handle_sideload
		$file_array = [
			'name'     => $filename,
			'tmp_name' => $temp_file,
			'type'     => $content_type,
			'size'     => strlen( $image_data ),
		];

		// Upload to media library
		$attachment_id = media_handle_sideload( $file_array, 0 );

		if ( is_wp_error( $attachment_id ) ) {
			unlink( $temp_file );
			return null;
		}

		// Clean up temp file
		unlink( $temp_file );

		return [
			'id' => $attachment_id,
			'url' => wp_get_attachment_url( $attachment_id ),
			'filename' => $filename,
		];
	}

	/**
	 * Create SEO-friendly filename.
	 *
	 * @param string $keyword Primary keyword.
	 * @param string $type Image type.
	 * @param string $extension File extension.
	 * @return string
	 */
	private function create_seo_filename( $keyword, $type, $extension ) {
		$slug = sanitize_title( $keyword );
		$timestamp = time();
		
		return "{$slug}-{$type}-{$timestamp}.{$extension}";
	}

	/**
	 * Generate SEO-optimized alt text.
	 *
	 * @param string $keyword Primary keyword.
	 * @param string $context Image context.
	 * @return string
	 */
	private function generate_alt_text( $keyword, $context ) {
		$templates = [
			'featured' => "{$keyword} - comprehensive guide and tips",
			'infographic' => "{$keyword} infographic with key statistics and data",
			'illustration' => "Illustration showing {$keyword} concepts and examples",
			'diagram' => "Diagram explaining {$keyword} process and workflow",
		];

		$template = $templates[ $context ] ?? "{$keyword} - informative image";
		
		// Ensure alt text is not too long
		if ( strlen( $template ) > 125 ) {
			$template = substr( $template, 0, 122 ) . '...';
		}

		return $template;
	}

	/**
	 * Generate image caption.
	 *
	 * @param string $keyword Primary keyword.
	 * @param string $title Article title.
	 * @param string $type Image type.
	 * @return string
	 */
	private function generate_caption( $keyword, $title, $type = 'featured' ) {
		$captions = [
			'featured' => "Everything you need to know about {$keyword}",
			'infographic' => "Key insights and data about {$keyword}",
			'illustration' => "Visual guide to understanding {$keyword}",
			'diagram' => "Step-by-step process for {$keyword}",
		];

		return $captions[ $type ] ?? "Learn more about {$keyword}";
	}

	/**
	 * Generate stock photo alternatives if AI generation fails.
	 *
	 * @param string $keyword Primary keyword.
	 * @return array
	 */
	private function get_stock_photo_suggestions( $keyword ) {
		// This could integrate with stock photo APIs like Unsplash, Pexels, etc.
		$suggestions = [
			'unsplash' => "https://unsplash.com/s/photos/" . urlencode( $keyword ),
			'pexels' => "https://www.pexels.com/search/" . urlencode( $keyword ),
			'pixabay' => "https://pixabay.com/images/search/" . urlencode( $keyword ),
		];

		return $suggestions;
	}

	/**
	 * Optimize existing images for SEO.
	 *
	 * @param array $images Array of image data.
	 * @param string $keyword Primary keyword.
	 * @return array
	 */
	public function optimize_existing_images( $images, $keyword ) {
		$optimized_images = [];

		foreach ( $images as $image ) {
			$optimized_image = $image;

			// Generate SEO-friendly alt text if missing
			if ( empty( $image['alt_text'] ) ) {
				$optimized_image['alt_text'] = $this->generate_alt_text( $keyword, 'content' );
			}

			// Generate caption if missing
			if ( empty( $image['caption'] ) ) {
				$optimized_image['caption'] = $this->generate_caption( $keyword, '', 'content' );
			}

			// Suggest filename optimization
			if ( ! empty( $image['filename'] ) ) {
				$optimized_image['suggested_filename'] = $this->create_seo_filename( $keyword, 'optimized', 'jpg' );
			}

			$optimized_images[] = $optimized_image;
		}

		return $optimized_images;
	}
}