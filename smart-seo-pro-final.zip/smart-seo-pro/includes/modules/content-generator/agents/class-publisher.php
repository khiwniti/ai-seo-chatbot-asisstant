<?php
/**
 * Publisher Agent.
 *
 * @since      1.0.0
 * @package    SmartSeo
 * @subpackage SmartSeoPro\ContentGenerator\Agents
 * @author     Smart SEO Team <support@smartseo.dev>
 */

namespace RankMathPro\ContentGenerator\Agents;

defined( 'ABSPATH' ) || exit;

/**
 * Publisher class.
 */
class Publisher {

	/**
	 * Prepare content for publishing.
	 *
	 * @param array $content Optimized content.
	 * @param array $media Generated media.
	 * @return array
	 */
	public function prepare_for_publishing( $content, $media ) {
		$publish_data = [
			'post_data' => $this->prepare_post_data( $content, $media ),
			'meta_data' => $this->prepare_meta_data( $content ),
			'media_attachments' => $this->prepare_media_attachments( $media ),
			'schema_markup' => $this->generate_schema_markup( $content ),
			'internal_links' => $this->suggest_internal_links( $content ),
			'publishing_checklist' => $this->generate_publishing_checklist( $content ),
		];

		return $publish_data;
	}

	/**
	 * Publish content to WordPress.
	 *
	 * @param array $publish_data Prepared publishing data.
	 * @param array $options Publishing options.
	 * @return int|WP_Error
	 */
	public function publish_to_wordpress( $publish_data, $options = [] ) {
		$defaults = [
			'post_status' => 'draft',
			'post_type' => 'post',
			'post_category' => [],
			'tags' => [],
			'featured_image' => true,
			'auto_internal_links' => false,
		];

		$options = wp_parse_args( $options, $defaults );

		// Create the post
		$post_id = wp_insert_post( $publish_data['post_data'] );

		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		// Add meta data
		$this->add_post_meta( $post_id, $publish_data['meta_data'] );

		// Set featured image
		if ( $options['featured_image'] && ! empty( $publish_data['media_attachments']['featured_image'] ) ) {
			set_post_thumbnail( $post_id, $publish_data['media_attachments']['featured_image']['id'] );
		}

		// Add categories and tags
		if ( ! empty( $options['post_category'] ) ) {
			wp_set_post_categories( $post_id, $options['post_category'] );
		}

		if ( ! empty( $options['tags'] ) ) {
			wp_set_post_tags( $post_id, $options['tags'] );
		}

		// Add schema markup
		if ( ! empty( $publish_data['schema_markup'] ) ) {
			update_post_meta( $post_id, '_smart_seo_schema_markup', $publish_data['schema_markup'] );
		}

		// Auto-add internal links if enabled
		if ( $options['auto_internal_links'] ) {
			$this->add_internal_links( $post_id, $publish_data['internal_links'] );
		}

		return $post_id;
	}

	/**
	 * Prepare WordPress post data.
	 *
	 * @param array $content Content data.
	 * @param array $media Media data.
	 * @return array
	 */
	private function prepare_post_data( $content, $media ) {
		$post_content = $content['full_html'];

		// Insert content images into the content
		if ( ! empty( $media['content_images'] ) ) {
			$post_content = $this->insert_content_images( $post_content, $media['content_images'] );
		}

		return [
			'post_title' => $content['title'],
			'post_content' => $post_content,
			'post_excerpt' => $this->generate_excerpt( $content ),
			'post_status' => 'draft',
			'post_type' => 'post',
			'post_name' => $content['url_slug'],
			'meta_input' => [
				'_smart_seo_generated' => true,
				'_smart_seo_generation_date' => current_time( 'mysql' ),
			],
		];
	}

	/**
	 * Prepare SEO meta data.
	 *
	 * @param array $content Content data.
	 * @return array
	 */
	private function prepare_meta_data( $content ) {
		return [
			'_smart_seo_meta_description' => $content['meta_description'],
			'_smart_seo_focus_keyword' => $content['keyword_analysis']['primary_keyword']['keyword'] ?? '',
			'_smart_seo_keyword_density' => $content['keyword_analysis']['primary_keyword']['density'] ?? 0,
			'_smart_seo_readability_score' => $content['readability']['score'] ?? 0,
			'_smart_seo_seo_score' => $content['seo_score'] ?? 0,
			'_smart_seo_word_count' => $content['keyword_analysis']['word_count'] ?? 0,
			'_smart_seo_recommendations' => $content['seo_recommendations'] ?? [],
		];
	}

	/**
	 * Prepare media attachments.
	 *
	 * @param array $media Media data.
	 * @return array
	 */
	private function prepare_media_attachments( $media ) {
		$attachments = [
			'featured_image' => null,
			'content_images' => [],
		];

		if ( ! empty( $media['featured_image'] ) ) {
			$attachments['featured_image'] = $media['featured_image'];
		}

		if ( ! empty( $media['content_images'] ) ) {
			$attachments['content_images'] = $media['content_images'];
		}

		return $attachments;
	}

	/**
	 * Generate schema markup.
	 *
	 * @param array $content Content data.
	 * @return array
	 */
	private function generate_schema_markup( $content ) {
		$schema = [
			'@context' => 'https://schema.org',
			'@type' => 'Article',
			'headline' => $content['title'],
			'description' => $content['meta_description'],
			'wordCount' => $content['keyword_analysis']['word_count'] ?? 0,
			'datePublished' => current_time( 'c' ),
			'dateModified' => current_time( 'c' ),
			'author' => [
				'@type' => 'Person',
				'name' => get_bloginfo( 'name' ),
			],
			'publisher' => [
				'@type' => 'Organization',
				'name' => get_bloginfo( 'name' ),
				'url' => home_url(),
			],
		];

		// Add FAQ schema if FAQ section exists
		if ( ! empty( $content['faq'] ) ) {
			$faq_schema = $this->generate_faq_schema( $content['faq'] );
			if ( $faq_schema ) {
				$schema['mainEntity'] = $faq_schema;
			}
		}

		return $schema;
	}

	/**
	 * Generate FAQ schema markup.
	 *
	 * @param string $faq_content FAQ content.
	 * @return array|null
	 */
	private function generate_faq_schema( $faq_content ) {
		// Extract Q&A pairs from FAQ content
		preg_match_all( '/<h[3-6][^>]*>(.*?)<\/h[3-6]>(.*?)(?=<h[3-6]|$)/s', $faq_content, $matches, PREG_SET_ORDER );

		if ( empty( $matches ) ) {
			return null;
		}

		$faq_items = [];
		foreach ( $matches as $match ) {
			$question = wp_strip_all_tags( $match[1] );
			$answer = wp_strip_all_tags( $match[2] );

			if ( ! empty( $question ) && ! empty( $answer ) ) {
				$faq_items[] = [
					'@type' => 'Question',
					'name' => trim( $question ),
					'acceptedAnswer' => [
						'@type' => 'Answer',
						'text' => trim( $answer ),
					],
				];
			}
		}

		if ( empty( $faq_items ) ) {
			return null;
		}

		return [
			'@type' => 'FAQPage',
			'mainEntity' => $faq_items,
		];
	}

	/**
	 * Suggest internal links.
	 *
	 * @param array $content Content data.
	 * @return array
	 */
	private function suggest_internal_links( $content ) {
		$suggestions = [];
		$primary_keyword = $content['keyword_analysis']['primary_keyword']['keyword'] ?? '';
		$lsi_keywords = [];

		// Extract LSI keywords
		if ( ! empty( $content['keyword_analysis']['lsi_keywords'] ) ) {
			foreach ( $content['keyword_analysis']['lsi_keywords'] as $kw ) {
				$lsi_keywords[] = $kw['keyword'];
			}
		}

		// Find related posts
		$related_posts = $this->find_related_posts( $primary_keyword, $lsi_keywords );

		foreach ( $related_posts as $post ) {
			$suggestions[] = [
				'post_id' => $post->ID,
				'title' => $post->post_title,
				'url' => get_permalink( $post->ID ),
				'anchor_text' => $this->suggest_anchor_text( $post->post_title, $primary_keyword ),
				'relevance_score' => $this->calculate_relevance_score( $post, $primary_keyword, $lsi_keywords ),
			];
		}

		// Sort by relevance score
		usort( $suggestions, function( $a, $b ) {
			return $b['relevance_score'] <=> $a['relevance_score'];
		} );

		return array_slice( $suggestions, 0, 5 );
	}

	/**
	 * Find related posts for internal linking.
	 *
	 * @param string $primary_keyword Primary keyword.
	 * @param array  $lsi_keywords LSI keywords.
	 * @return array
	 */
	private function find_related_posts( $primary_keyword, $lsi_keywords ) {
		$search_terms = array_merge( [ $primary_keyword ], array_slice( $lsi_keywords, 0, 5 ) );
		$search_query = implode( ' OR ', $search_terms );

		$args = [
			's' => $search_query,
			'post_type' => 'post',
			'post_status' => 'publish',
			'posts_per_page' => 10,
			'orderby' => 'relevance',
		];

		return get_posts( $args );
	}

	/**
	 * Calculate relevance score for internal linking.
	 *
	 * @param WP_Post $post Post object.
	 * @param string  $primary_keyword Primary keyword.
	 * @param array   $lsi_keywords LSI keywords.
	 * @return float
	 */
	private function calculate_relevance_score( $post, $primary_keyword, $lsi_keywords ) {
		$score = 0;
		$content = $post->post_title . ' ' . $post->post_content;
		$content = strtolower( wp_strip_all_tags( $content ) );

		// Check primary keyword
		if ( strpos( $content, strtolower( $primary_keyword ) ) !== false ) {
			$score += 10;
		}

		// Check LSI keywords
		foreach ( $lsi_keywords as $keyword ) {
			if ( strpos( $content, strtolower( $keyword ) ) !== false ) {
				$score += 2;
			}
		}

		// Bonus for recent posts
		$post_age_days = ( time() - strtotime( $post->post_date ) ) / DAY_IN_SECONDS;
		if ( $post_age_days < 30 ) {
			$score += 3;
		} elseif ( $post_age_days < 90 ) {
			$score += 1;
		}

		return $score;
	}

	/**
	 * Suggest anchor text for internal links.
	 *
	 * @param string $post_title Post title.
	 * @param string $primary_keyword Primary keyword.
	 * @return string
	 */
	private function suggest_anchor_text( $post_title, $primary_keyword ) {
		// Use post title if it's short enough
		if ( strlen( $post_title ) <= 60 ) {
			return $post_title;
		}

		// Try to create anchor text with primary keyword
		$words = explode( ' ', $post_title );
		$anchor_words = [];

		foreach ( $words as $word ) {
			$anchor_words[] = $word;
			if ( strlen( implode( ' ', $anchor_words ) ) > 50 ) {
				break;
			}
		}

		return implode( ' ', $anchor_words );
	}

	/**
	 * Generate publishing checklist.
	 *
	 * @param array $content Content data.
	 * @return array
	 */
	private function generate_publishing_checklist( $content ) {
		$checklist = [];

		// SEO checks
		$seo_score = $content['seo_score'] ?? 0;
		$checklist[] = [
			'item' => 'SEO Score',
			'status' => $seo_score >= 80 ? 'good' : ( $seo_score >= 60 ? 'warning' : 'error' ),
			'message' => "Current SEO score: {$seo_score}/100",
		];

		// Keyword density check
		$keyword_density = $content['keyword_analysis']['primary_keyword']['density'] ?? 0;
		$checklist[] = [
			'item' => 'Keyword Density',
			'status' => ( $keyword_density >= 0.5 && $keyword_density <= 3.0 ) ? 'good' : 'warning',
			'message' => "Primary keyword density: {$keyword_density}%",
		];

		// Meta description check
		$meta_length = strlen( $content['meta_description'] );
		$checklist[] = [
			'item' => 'Meta Description',
			'status' => ( $meta_length >= 140 && $meta_length <= 160 ) ? 'good' : 'warning',
			'message' => "Meta description length: {$meta_length} characters",
		];

		// Readability check
		$readability_score = $content['readability']['score'] ?? 0;
		$checklist[] = [
			'item' => 'Readability',
			'status' => $readability_score >= 60 ? 'good' : 'warning',
			'message' => "Readability score: {$readability_score} ({$content['readability']['level']})",
		];

		// Word count check
		$word_count = $content['keyword_analysis']['word_count'] ?? 0;
		$checklist[] = [
			'item' => 'Word Count',
			'status' => $word_count >= 300 ? 'good' : 'warning',
			'message' => "Word count: {$word_count} words",
		];

		return $checklist;
	}

	/**
	 * Insert content images into post content.
	 *
	 * @param string $content Post content.
	 * @param array  $images Content images.
	 * @return string
	 */
	private function insert_content_images( $content, $images ) {
		if ( empty( $images ) ) {
			return $content;
		}

		// Split content into sections
		$sections = preg_split( '/(<h[2-3][^>]*>.*?<\/h[2-3]>)/i', $content, -1, PREG_SPLIT_DELIM_CAPTURE );

		$image_index = 0;
		$modified_content = '';

		foreach ( $sections as $index => $section ) {
			$modified_content .= $section;

			// Insert image after every 2-3 sections
			if ( $index > 0 && $index % 4 === 0 && $image_index < count( $images ) ) {
				$image = $images[ $image_index ];
				$image_html = $this->generate_image_html( $image );
				$modified_content .= "\n\n" . $image_html . "\n\n";
				$image_index++;
			}
		}

		return $modified_content;
	}

	/**
	 * Generate HTML for content image.
	 *
	 * @param array $image Image data.
	 * @return string
	 */
	private function generate_image_html( $image ) {
		$html = '<figure class="wp-block-image">';
		$html .= '<img src="' . esc_url( $image['url'] ) . '" alt="' . esc_attr( $image['alt_text'] ) . '" />';
		
		if ( ! empty( $image['caption'] ) ) {
			$html .= '<figcaption>' . esc_html( $image['caption'] ) . '</figcaption>';
		}
		
		$html .= '</figure>';

		return $html;
	}

	/**
	 * Generate excerpt from content.
	 *
	 * @param array $content Content data.
	 * @return string
	 */
	private function generate_excerpt( $content ) {
		$text = wp_strip_all_tags( $content['introduction'] ?? $content['full_html'] );
		$excerpt = wp_trim_words( $text, 30, '...' );
		
		return $excerpt;
	}

	/**
	 * Add post meta data.
	 *
	 * @param int   $post_id Post ID.
	 * @param array $meta_data Meta data.
	 */
	private function add_post_meta( $post_id, $meta_data ) {
		foreach ( $meta_data as $key => $value ) {
			update_post_meta( $post_id, $key, $value );
		}
	}

	/**
	 * Add internal links to post content.
	 *
	 * @param int   $post_id Post ID.
	 * @param array $internal_links Internal link suggestions.
	 */
	private function add_internal_links( $post_id, $internal_links ) {
		if ( empty( $internal_links ) ) {
			return;
		}

		$post = get_post( $post_id );
		if ( ! $post ) {
			return;
		}

		$content = $post->post_content;

		// Add internal links to content
		foreach ( array_slice( $internal_links, 0, 3 ) as $link ) {
			$anchor_text = $link['anchor_text'];
			$url = $link['url'];
			
			// Find a good place to insert the link
			$link_html = '<a href="' . esc_url( $url ) . '">' . esc_html( $anchor_text ) . '</a>';
			
			// Simple replacement - in a real implementation, you'd want more sophisticated placement
			$content = preg_replace( '/\b' . preg_quote( $anchor_text, '/' ) . '\b/', $link_html, $content, 1 );
		}

		// Update post content
		wp_update_post( [
			'ID' => $post_id,
			'post_content' => $content,
		] );
	}
}