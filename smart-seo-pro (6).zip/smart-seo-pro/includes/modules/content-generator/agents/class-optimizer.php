<?php
/**
 * Content Optimizer Agent.
 *
 * @since      1.0.0
 * @package    SmartSeo
 * @subpackage SmartSeoPro\ContentGenerator\Agents
 * @author     Smart SEO Team <support@smartseo.dev>
 */

namespace RankMathPro\ContentGenerator\Agents;

defined( 'ABSPATH' ) || exit;

/**
 * Optimizer class.
 */
class Optimizer {

	/**
	 * Optimize content for SEO.
	 *
	 * @param array  $content Generated content.
	 * @param string $primary_keyword Primary keyword.
	 * @param array  $keywords All keywords data.
	 * @return array
	 */
	public function optimize_content( $content, $primary_keyword, $keywords ) {
		$optimized_content = $content;

		// Analyze and optimize keyword density
		$optimized_content['keyword_analysis'] = $this->analyze_keyword_density( $content['full_html'], $primary_keyword, $keywords );

		// Optimize meta description
		$optimized_content['meta_description'] = $this->optimize_meta_description( $content['meta_description'], $primary_keyword );

		// Calculate Flesch reading score
		$optimized_content['readability'] = $this->calculate_readability_score( $content['full_html'] );

		// Generate URL slug
		$optimized_content['url_slug'] = $this->generate_url_slug( $content['title'] );

		// Analyze content structure
		$optimized_content['structure_analysis'] = $this->analyze_content_structure( $content['full_html'] );

		// Generate SEO recommendations
		$optimized_content['seo_recommendations'] = $this->generate_seo_recommendations( $optimized_content, $primary_keyword );

		// Calculate overall SEO score
		$optimized_content['seo_score'] = $this->calculate_seo_score( $optimized_content, $primary_keyword );

		return $optimized_content;
	}

	/**
	 * Analyze keyword density.
	 *
	 * @param string $content HTML content.
	 * @param string $primary_keyword Primary keyword.
	 * @param array  $keywords All keywords data.
	 * @return array
	 */
	private function analyze_keyword_density( $content, $primary_keyword, $keywords ) {
		$text_content = wp_strip_all_tags( $content );
		$word_count = str_word_count( $text_content );
		
		$analysis = [
			'word_count' => $word_count,
			'primary_keyword' => [
				'keyword' => $primary_keyword,
				'count' => $this->count_keyword_occurrences( $text_content, $primary_keyword ),
				'density' => 0,
				'status' => 'low',
			],
			'lsi_keywords' => [],
			'related_keywords' => [],
		];

		// Calculate primary keyword density
		if ( $word_count > 0 ) {
			$analysis['primary_keyword']['density'] = ( $analysis['primary_keyword']['count'] / $word_count ) * 100;
			$analysis['primary_keyword']['status'] = $this->get_keyword_density_status( $analysis['primary_keyword']['density'] );
		}

		// Analyze LSI keywords
		$lsi_keywords = $this->extract_keyword_list( $keywords['lsi'] ?? [] );
		foreach ( array_slice( $lsi_keywords, 0, 10 ) as $keyword ) {
			$count = $this->count_keyword_occurrences( $text_content, $keyword );
			$density = $word_count > 0 ? ( $count / $word_count ) * 100 : 0;
			
			$analysis['lsi_keywords'][] = [
				'keyword' => $keyword,
				'count' => $count,
				'density' => $density,
				'status' => $count > 0 ? 'good' : 'missing',
			];
		}

		// Analyze related keywords
		$related_keywords = $this->extract_keyword_list( $keywords['related'] ?? [] );
		foreach ( array_slice( $related_keywords, 0, 5 ) as $keyword_data ) {
			$keyword = is_array( $keyword_data ) ? $keyword_data['keyword'] : $keyword_data;
			$count = $this->count_keyword_occurrences( $text_content, $keyword );
			$density = $word_count > 0 ? ( $count / $word_count ) * 100 : 0;
			
			$analysis['related_keywords'][] = [
				'keyword' => $keyword,
				'count' => $count,
				'density' => $density,
				'status' => $count > 0 ? 'good' : 'missing',
			];
		}

		return $analysis;
	}

	/**
	 * Count keyword occurrences in text.
	 *
	 * @param string $text Text content.
	 * @param string $keyword Keyword to count.
	 * @return int
	 */
	private function count_keyword_occurrences( $text, $keyword ) {
		$text = strtolower( $text );
		$keyword = strtolower( $keyword );
		
		// Count exact matches and partial matches
		$exact_count = substr_count( $text, $keyword );
		
		// Also count word variations (simple stemming)
		$words = explode( ' ', $keyword );
		$partial_count = 0;
		
		foreach ( $words as $word ) {
			if ( strlen( $word ) > 3 ) {
				$partial_count += substr_count( $text, $word );
			}
		}
		
		return max( $exact_count, $partial_count );
	}

	/**
	 * Get keyword density status.
	 *
	 * @param float $density Keyword density percentage.
	 * @return string
	 */
	private function get_keyword_density_status( $density ) {
		if ( $density < 0.5 ) {
			return 'low';
		} elseif ( $density > 3.0 ) {
			return 'high';
		} else {
			return 'good';
		}
	}

	/**
	 * Optimize meta description.
	 *
	 * @param string $meta_description Original meta description.
	 * @param string $primary_keyword Primary keyword.
	 * @return string
	 */
	private function optimize_meta_description( $meta_description, $primary_keyword ) {
		$length = strlen( $meta_description );
		
		// If too short, try to expand
		if ( $length < 140 ) {
			if ( stripos( $meta_description, $primary_keyword ) === false ) {
				$meta_description = $primary_keyword . ' - ' . $meta_description;
			}
		}
		
		// If too long, truncate smartly
		if ( strlen( $meta_description ) > 160 ) {
			$meta_description = substr( $meta_description, 0, 157 ) . '...';
		}
		
		return $meta_description;
	}

	/**
	 * Calculate Flesch reading score.
	 *
	 * @param string $content HTML content.
	 * @return array
	 */
	private function calculate_readability_score( $content ) {
		$text = wp_strip_all_tags( $content );
		
		// Count sentences
		$sentence_count = preg_match_all( '/[.!?]+/', $text );
		
		// Count words
		$word_count = str_word_count( $text );
		
		// Count syllables (approximation)
		$syllable_count = $this->count_syllables( $text );
		
		if ( $sentence_count == 0 || $word_count == 0 ) {
			return [
				'score' => 0,
				'level' => 'unknown',
				'description' => 'Unable to calculate readability',
			];
		}
		
		// Flesch Reading Ease formula
		$score = 206.835 - ( 1.015 * ( $word_count / $sentence_count ) ) - ( 84.6 * ( $syllable_count / $word_count ) );
		$score = max( 0, min( 100, $score ) );
		
		return [
			'score' => round( $score, 1 ),
			'level' => $this->get_readability_level( $score ),
			'description' => $this->get_readability_description( $score ),
			'word_count' => $word_count,
			'sentence_count' => $sentence_count,
			'syllable_count' => $syllable_count,
		];
	}

	/**
	 * Count syllables in text (approximation).
	 *
	 * @param string $text Text content.
	 * @return int
	 */
	private function count_syllables( $text ) {
		$text = strtolower( $text );
		$text = preg_replace( '/[^a-z]/', ' ', $text );
		$words = array_filter( explode( ' ', $text ) );
		
		$syllable_count = 0;
		
		foreach ( $words as $word ) {
			$syllable_count += $this->count_word_syllables( $word );
		}
		
		return $syllable_count;
	}

	/**
	 * Count syllables in a single word.
	 *
	 * @param string $word Word.
	 * @return int
	 */
	private function count_word_syllables( $word ) {
		$word = strtolower( $word );
		$vowels = 'aeiouy';
		$syllable_count = 0;
		$previous_was_vowel = false;
		
		for ( $i = 0; $i < strlen( $word ); $i++ ) {
			$is_vowel = strpos( $vowels, $word[ $i ] ) !== false;
			
			if ( $is_vowel && ! $previous_was_vowel ) {
				$syllable_count++;
			}
			
			$previous_was_vowel = $is_vowel;
		}
		
		// Handle silent 'e'
		if ( substr( $word, -1 ) === 'e' && $syllable_count > 1 ) {
			$syllable_count--;
		}
		
		return max( 1, $syllable_count );
	}

	/**
	 * Get readability level.
	 *
	 * @param float $score Flesch score.
	 * @return string
	 */
	private function get_readability_level( $score ) {
		if ( $score >= 90 ) {
			return 'very_easy';
		} elseif ( $score >= 80 ) {
			return 'easy';
		} elseif ( $score >= 70 ) {
			return 'fairly_easy';
		} elseif ( $score >= 60 ) {
			return 'standard';
		} elseif ( $score >= 50 ) {
			return 'fairly_difficult';
		} elseif ( $score >= 30 ) {
			return 'difficult';
		} else {
			return 'very_difficult';
		}
	}

	/**
	 * Get readability description.
	 *
	 * @param float $score Flesch score.
	 * @return string
	 */
	private function get_readability_description( $score ) {
		$descriptions = [
			'very_easy' => 'Very Easy (5th grade level)',
			'easy' => 'Easy (6th grade level)',
			'fairly_easy' => 'Fairly Easy (7th grade level)',
			'standard' => 'Standard (8th-9th grade level)',
			'fairly_difficult' => 'Fairly Difficult (10th-12th grade level)',
			'difficult' => 'Difficult (College level)',
			'very_difficult' => 'Very Difficult (Graduate level)',
		];
		
		$level = $this->get_readability_level( $score );
		return $descriptions[ $level ] ?? 'Unknown';
	}

	/**
	 * Generate URL slug.
	 *
	 * @param string $title Content title.
	 * @return string
	 */
	private function generate_url_slug( $title ) {
		$slug = strtolower( $title );
		$slug = preg_replace( '/[^a-z0-9\s-]/', '', $slug );
		$slug = preg_replace( '/\s+/', '-', $slug );
		$slug = trim( $slug, '-' );
		
		// Limit length
		if ( strlen( $slug ) > 60 ) {
			$slug = substr( $slug, 0, 60 );
			$slug = preg_replace( '/-[^-]*$/', '', $slug );
		}
		
		return $slug;
	}

	/**
	 * Analyze content structure.
	 *
	 * @param string $content HTML content.
	 * @return array
	 */
	private function analyze_content_structure( $content ) {
		$analysis = [
			'headings' => [],
			'images' => 0,
			'links' => 0,
			'lists' => 0,
			'paragraphs' => 0,
		];

		// Count headings
		for ( $i = 1; $i <= 6; $i++ ) {
			$count = preg_match_all( "/<h{$i}[^>]*>(.*?)<\/h{$i}>/i", $content, $matches );
			if ( $count > 0 ) {
				$analysis['headings'][ "h{$i}" ] = [
					'count' => $count,
					'text' => $matches[1] ?? [],
				];
			}
		}

		// Count other elements
		$analysis['images'] = preg_match_all( '/<img[^>]*>/i', $content );
		$analysis['links'] = preg_match_all( '/<a[^>]*href[^>]*>/i', $content );
		$analysis['lists'] = preg_match_all( '/<(ul|ol)[^>]*>/i', $content );
		$analysis['paragraphs'] = preg_match_all( '/<p[^>]*>/i', $content );

		return $analysis;
	}

	/**
	 * Generate SEO recommendations.
	 *
	 * @param array  $content Optimized content data.
	 * @param string $primary_keyword Primary keyword.
	 * @return array
	 */
	private function generate_seo_recommendations( $content, $primary_keyword ) {
		$recommendations = [];

		// Keyword density recommendations
		$primary_density = $content['keyword_analysis']['primary_keyword']['density'];
		if ( $primary_density < 0.5 ) {
			$recommendations[] = [
				'type' => 'warning',
				'message' => "Primary keyword density is low ({$primary_density}%). Consider adding '{$primary_keyword}' more naturally throughout the content.",
			];
		} elseif ( $primary_density > 3.0 ) {
			$recommendations[] = [
				'type' => 'warning',
				'message' => "Primary keyword density is high ({$primary_density}%). Consider reducing keyword usage to avoid over-optimization.",
			];
		}

		// Meta description recommendations
		$meta_length = strlen( $content['meta_description'] );
		if ( $meta_length < 140 ) {
			$recommendations[] = [
				'type' => 'warning',
				'message' => "Meta description is too short ({$meta_length} characters). Aim for 150-160 characters.",
			];
		} elseif ( $meta_length > 160 ) {
			$recommendations[] = [
				'type' => 'warning',
				'message' => "Meta description is too long ({$meta_length} characters). It may be truncated in search results.",
			];
		}

		// Readability recommendations
		$readability_score = $content['readability']['score'];
		if ( $readability_score < 60 ) {
			$recommendations[] = [
				'type' => 'info',
				'message' => "Content readability could be improved. Consider using shorter sentences and simpler words.",
			];
		}

		// Structure recommendations
		$structure = $content['structure_analysis'];
		if ( empty( $structure['headings']['h2'] ) ) {
			$recommendations[] = [
				'type' => 'warning',
				'message' => "No H2 headings found. Add H2 headings to improve content structure.",
			];
		}

		if ( $structure['images'] == 0 ) {
			$recommendations[] = [
				'type' => 'info',
				'message' => "No images found. Consider adding relevant images to improve user engagement.",
			];
		}

		// Word count recommendations
		$word_count = $content['keyword_analysis']['word_count'];
		if ( $word_count < 300 ) {
			$recommendations[] = [
				'type' => 'warning',
				'message' => "Content is quite short ({$word_count} words). Consider expanding for better SEO performance.",
			];
		}

		return $recommendations;
	}

	/**
	 * Calculate overall SEO score.
	 *
	 * @param array  $content Optimized content data.
	 * @param string $primary_keyword Primary keyword.
	 * @return int
	 */
	private function calculate_seo_score( $content, $primary_keyword ) {
		$score = 0;

		// Keyword optimization (30 points)
		$primary_density = $content['keyword_analysis']['primary_keyword']['density'];
		if ( $primary_density >= 0.5 && $primary_density <= 3.0 ) {
			$score += 30;
		} elseif ( $primary_density > 0 ) {
			$score += 15;
		}

		// Meta description (20 points)
		$meta_length = strlen( $content['meta_description'] );
		if ( $meta_length >= 140 && $meta_length <= 160 ) {
			$score += 20;
		} elseif ( $meta_length >= 120 && $meta_length <= 180 ) {
			$score += 15;
		} elseif ( $meta_length > 0 ) {
			$score += 10;
		}

		// Readability (20 points)
		$readability_score = $content['readability']['score'];
		if ( $readability_score >= 60 ) {
			$score += 20;
		} elseif ( $readability_score >= 40 ) {
			$score += 15;
		} elseif ( $readability_score >= 20 ) {
			$score += 10;
		}

		// Content structure (20 points)
		$structure = $content['structure_analysis'];
		if ( ! empty( $structure['headings']['h2'] ) ) {
			$score += 10;
		}
		if ( ! empty( $structure['headings']['h3'] ) ) {
			$score += 5;
		}
		if ( $structure['images'] > 0 ) {
			$score += 5;
		}

		// Word count (10 points)
		$word_count = $content['keyword_analysis']['word_count'];
		if ( $word_count >= 1000 ) {
			$score += 10;
		} elseif ( $word_count >= 500 ) {
			$score += 7;
		} elseif ( $word_count >= 300 ) {
			$score += 5;
		}

		return min( 100, $score );
	}

	/**
	 * Extract keyword list from keyword data.
	 *
	 * @param array $keyword_data Keyword data.
	 * @return array
	 */
	private function extract_keyword_list( $keyword_data ) {
		if ( empty( $keyword_data ) ) {
			return [];
		}

		$keywords = [];
		foreach ( $keyword_data as $kw ) {
			if ( is_array( $kw ) && isset( $kw['keyword'] ) ) {
				$keywords[] = $kw['keyword'];
			} elseif ( is_string( $kw ) ) {
				$keywords[] = $kw;
			}
		}

		return $keywords;
	}
}