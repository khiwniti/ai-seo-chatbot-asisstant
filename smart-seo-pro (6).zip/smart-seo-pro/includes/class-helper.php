<?php
/**
 * Helper class.
 *
 * @package SmartSeoPro
 */

namespace RankMath;

/**
 * Helper class.
 */
class Helper {

	/**
	 * Get option value.
	 *
	 * @param string $key     Option key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public static function get_option( $key, $default = '' ) {
		if ( function_exists( 'get_option' ) ) {
			return get_option( $key, $default );
		}
		return $default;
	}

	/**
	 * Update option value.
	 *
	 * @param string $key   Option key.
	 * @param mixed  $value Option value.
	 * @return bool
	 */
	public static function update_option( $key, $value ) {
		if ( function_exists( 'update_option' ) ) {
			return update_option( $key, $value );
		}
		return false;
	}

	/**
	 * Get settings.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public static function get_settings( $key = '', $default = '' ) {
		$settings = self::get_option( 'rank_math_options', [] );
		
		if ( empty( $key ) ) {
			return $settings;
		}
		
		return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
	}

	/**
	 * Check if module is active.
	 *
	 * @param string $module Module name.
	 * @return bool
	 */
	public static function is_module_active( $module ) {
		$modules = self::get_settings( 'modules', [] );
		return isset( $modules[ $module ] ) && 'on' === $modules[ $module ];
	}

	/**
	 * Get post meta.
	 *
	 * @param string $key     Meta key.
	 * @param int    $post_id Post ID.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public static function get_post_meta( $key, $post_id = 0, $default = '' ) {
		if ( ! function_exists( 'get_post_meta' ) ) {
			return $default;
		}
		
		$post_id = empty( $post_id ) && function_exists( 'get_the_ID' ) ? get_the_ID() : $post_id;
		$value   = get_post_meta( $post_id, $key, true );
		
		return empty( $value ) ? $default : $value;
	}

	/**
	 * Check if we're on admin.
	 *
	 * @return bool
	 */
	public static function is_admin() {
		return function_exists( 'is_admin' ) ? is_admin() : false;
	}

	/**
	 * Check if we're on frontend.
	 *
	 * @return bool
	 */
	public static function is_frontend() {
		return ! self::is_admin();
	}

	/**
	 * Check if it's a heartbeat request.
	 *
	 * @return bool
	 */
	public static function is_heartbeat() {
		return defined( 'DOING_AJAX' ) && DOING_AJAX && isset( $_POST['action'] ) && 'heartbeat' === $_POST['action'];
	}

	/**
	 * Check if it's a REST request.
	 *
	 * @return bool
	 */
	public static function is_rest() {
		return defined( 'REST_REQUEST' ) && REST_REQUEST;
	}

	/**
	 * Check if user has capability.
	 *
	 * @param string $capability Capability to check.
	 * @return bool
	 */
	public static function has_cap( $capability ) {
		if ( function_exists( 'current_user_can' ) ) {
			return current_user_can( $capability );
		}
		return true; // Mock capability check
	}

	/**
	 * Get current post type.
	 *
	 * @return string
	 */
	public static function get_current_post_type() {
		if ( function_exists( 'get_post_type' ) ) {
			return get_post_type();
		}
		return 'post';
	}

	/**
	 * Get accessible post types.
	 *
	 * @return array
	 */
	public static function get_accessible_post_types() {
		if ( function_exists( 'get_post_types' ) ) {
			return get_post_types( [ 'public' => true ] );
		}
		return [ 'post', 'page' ];
	}

	/**
	 * Get accessible taxonomies.
	 *
	 * @return array
	 */
	public static function get_accessible_taxonomies() {
		if ( function_exists( 'get_taxonomies' ) ) {
			return get_taxonomies( [ 'public' => true ] );
		}
		return [ 'category', 'post_tag' ];
	}

	/**
	 * Get admin URL.
	 *
	 * @param string $path Path to append.
	 * @return string
	 */
	public static function get_admin_url( $path = '' ) {
		if ( function_exists( 'admin_url' ) ) {
			return admin_url( $path );
		}
		return '/wp-admin/' . $path;
	}

	/**
	 * Get home URL.
	 *
	 * @return string
	 */
	public static function get_home_url() {
		if ( function_exists( 'home_url' ) ) {
			return home_url();
		}
		return 'http://localhost';
	}

	/**
	 * Check if WooCommerce is active.
	 *
	 * @return bool
	 */
	public static function is_woocommerce_active() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Check if EDD is active.
	 *
	 * @return bool
	 */
	public static function is_edd_active() {
		return class_exists( 'Easy_Digital_Downloads' );
	}

	/**
	 * Check if AMP is active.
	 *
	 * @return bool
	 */
	public static function is_amp_active() {
		return function_exists( 'amp_is_request' );
	}

	/**
	 * Replace variables in content.
	 *
	 * @param string $content Content with variables.
	 * @param array  $args    Arguments for replacement.
	 * @return string
	 */
	public static function replace_vars( $content, $args = [] ) {
		// Basic variable replacement
		$replacements = [
			'%title%'       => get_the_title(),
			'%sitename%'    => get_bloginfo( 'name' ),
			'%sitedesc%'    => get_bloginfo( 'description' ),
			'%currentdate%' => date( 'Y-m-d' ),
			'%currentyear%' => date( 'Y' ),
		];

		return str_replace( array_keys( $replacements ), array_values( $replacements ), $content );
	}

	/**
	 * Strip shortcodes from content.
	 *
	 * @param string $content Content with shortcodes.
	 * @return string
	 */
	public static function strip_shortcodes( $content ) {
		if ( function_exists( 'strip_shortcodes' ) ) {
			return strip_shortcodes( $content );
		}
		return preg_replace( '/\[.*?\]/', '', $content );
	}

	/**
	 * Check if string starts with.
	 *
	 * @param string $haystack String to search in.
	 * @param string $needle   String to search for.
	 * @return bool
	 */
	public static function starts_with( $haystack, $needle ) {
		return substr( $haystack, 0, strlen( $needle ) ) === $needle;
	}

	/**
	 * Get URL part.
	 *
	 * @param string $url  URL to parse.
	 * @param string $part Part to get.
	 * @return string
	 */
	public static function get_url_part( $url, $part ) {
		$parsed = parse_url( $url );
		return isset( $parsed[ $part ] ) ? $parsed[ $part ] : '';
	}

	/**
	 * Check if URL is image.
	 *
	 * @param string $url URL to check.
	 * @return bool
	 */
	public static function is_image_url( $url ) {
		$image_extensions = [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg' ];
		$extension = pathinfo( $url, PATHINFO_EXTENSION );
		return in_array( strtolower( $extension ), $image_extensions );
	}

	/**
	 * Mock methods for compatibility.
	 */
	public static function is_wizard() { return false; }
	public static function is_post_edit() { return false; }
	public static function is_term_edit() { return false; }
	public static function is_user_edit() { return false; }
	public static function is_post_list() { return false; }
	public static function is_posts_page() { return false; }
	public static function is_localhost() { return false; }
	public static function is_site_connected() { return true; }
	public static function is_business_plan() { return true; }
	public static function is_plan_expired() { return false; }
	public static function get_plan() { return 'business'; }
	public static function get_user_plan() { return 'business'; }
	public static function is_elementor_editor() { return false; }
	public static function is_divi_frontend_editor() { return false; }
	public static function is_site_editor() { return false; }
	public static function get_current_editor() { return 'classic'; }
	public static function is_breadcrumbs_enabled() { return true; }
	public static function get_primary_taxonomy() { return 'category'; }
	public static function get_primary_term_id() { return 0; }
	public static function get_post_type_label( $post_type ) { return ucfirst( $post_type ); }
	public static function get_default_schema_type() { return 'Article'; }
	public static function can_add_frontend_stats() { return true; }
	public static function can_add_index_status() { return true; }
	public static function is_term_profile_page() { return false; }
	public static function is_post_indexable() { return true; }
	public static function get_request_action() { return ''; }
	public static function get_robots_defaults() { return []; }
	public static function get_allowed_post_types() { return [ 'post', 'page' ]; }
	public static function get_allowed_taxonomies() { return [ 'category', 'post_tag' ]; }
	public static function get_object_taxonomies( $post_type ) { return []; }
	public static function get_taxonomy_terms( $taxonomy ) { return []; }
	public static function choices_post_types() { return []; }
	public static function choices_business_types() { return []; }
	public static function choices_countries() { return []; }
	public static function choices_phone_types() { return []; }
	public static function choices_overlay_images() { return []; }
	public static function choices_additional_organization_info() { return []; }
	public static function get_module( $module ) { return null; }
	public static function get_registration_data() { return []; }
	public static function get_connect_url() { return ''; }
	public static function get_activate_url() { return ''; }
	public static function get_filesystem() { return null; }
	public static function is_filesystem_direct() { return true; }
	public static function get_htaccess_data() { return ''; }
	public static function check_table_exists( $table ) { return true; }
	public static function enable_big_selects_for_queries() { return true; }
	public static function duration_to_seconds( $duration ) { return 0; }
	public static function get_formatted_duration( $seconds ) { return '0s'; }
	public static function sanitize_schema_title( $title ) { return sanitize_text_field( $title ); }
	public static function schedule_flush_rewrite() { return true; }
	public static function set_capabilities() { return true; }
	public static function update_all_settings( $settings ) { return true; }
	public static function update_modules( $modules ) { return true; }
	public static function add_json( $data ) { return true; }
	public static function add_notification( $message, $type = 'info' ) { return true; }
	public static function replace_seo_fields( $content ) { return $content; }
}