<?php
/**
 * Hooker trait.
 *
 * @package SmartSeoPro
 */

namespace RankMath\Traits;

/**
 * Hooker trait.
 */
trait Hooker {

	/**
	 * Add action hook.
	 *
	 * @param string   $hook     Hook name.
	 * @param callable $callback Callback function.
	 * @param int      $priority Priority.
	 * @param int      $args     Number of arguments.
	 */
	public function action( $hook, $callback, $priority = 10, $args = 1 ) {
		if ( function_exists( 'add_action' ) ) {
			add_action( $hook, [ $this, $callback ], $priority, $args );
		}
	}

	/**
	 * Add filter hook.
	 *
	 * @param string   $hook     Hook name.
	 * @param callable $callback Callback function.
	 * @param int      $priority Priority.
	 * @param int      $args     Number of arguments.
	 */
	public function filter( $hook, $callback, $priority = 10, $args = 1 ) {
		if ( function_exists( 'add_filter' ) ) {
			add_filter( $hook, [ $this, $callback ], $priority, $args );
		}
	}

	/**
	 * Remove action hook.
	 *
	 * @param string   $hook     Hook name.
	 * @param callable $callback Callback function.
	 * @param int      $priority Priority.
	 */
	public function remove_action( $hook, $callback, $priority = 10 ) {
		if ( function_exists( 'remove_action' ) ) {
			remove_action( $hook, [ $this, $callback ], $priority );
		}
	}

	/**
	 * Remove filter hook.
	 *
	 * @param string   $hook     Hook name.
	 * @param callable $callback Callback function.
	 * @param int      $priority Priority.
	 */
	public function remove_filter( $hook, $callback, $priority = 10 ) {
		if ( function_exists( 'remove_filter' ) ) {
			remove_filter( $hook, [ $this, $callback ], $priority );
		}
	}
}