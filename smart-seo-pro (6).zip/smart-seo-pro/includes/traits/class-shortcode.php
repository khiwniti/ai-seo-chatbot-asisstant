<?php
/**
 * Shortcode trait.
 *
 * @package SmartSeoPro
 */

namespace RankMath\Traits;

/**
 * Shortcode trait.
 */
trait Shortcode {

	/**
	 * Add shortcode.
	 *
	 * @param string $tag      Shortcode tag.
	 * @param string $callback Callback method.
	 */
	public function add_shortcode( $tag, $callback = '' ) {
		$callback = empty( $callback ) ? $tag : $callback;
		
		if ( function_exists( 'add_shortcode' ) ) {
			add_shortcode( $tag, [ $this, $callback ] );
		}
	}

	/**
	 * Remove shortcode.
	 *
	 * @param string $tag Shortcode tag.
	 */
	public function remove_shortcode( $tag ) {
		if ( function_exists( 'remove_shortcode' ) ) {
			remove_shortcode( $tag );
		}
	}

	/**
	 * Do shortcode.
	 *
	 * @param string $content Content with shortcodes.
	 * @return string
	 */
	public function do_shortcode( $content ) {
		if ( function_exists( 'do_shortcode' ) ) {
			return do_shortcode( $content );
		}
		return $content;
	}

	/**
	 * Parse shortcode attributes.
	 *
	 * @param array  $defaults Default attributes.
	 * @param array  $atts     User attributes.
	 * @param string $tag      Shortcode tag.
	 * @return array
	 */
	public function parse_atts( $defaults, $atts, $tag = '' ) {
		if ( function_exists( 'shortcode_atts' ) ) {
			return shortcode_atts( $defaults, $atts, $tag );
		}
		return array_merge( $defaults, (array) $atts );
	}
}