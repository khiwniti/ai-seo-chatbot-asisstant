<?php
/**
 * Meta trait.
 *
 * @package SmartSeoPro
 */

namespace RankMath\Traits;

/**
 * Meta trait.
 */
trait Meta {

	/**
	 * Get post meta.
	 *
	 * @param string $key     Meta key.
	 * @param int    $post_id Post ID.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public function get_meta( $key, $post_id = 0, $default = '' ) {
		if ( ! function_exists( 'get_post_meta' ) ) {
			return $default;
		}
		
		$post_id = empty( $post_id ) ? get_the_ID() : $post_id;
		$value   = get_post_meta( $post_id, $key, true );
		
		return empty( $value ) ? $default : $value;
	}

	/**
	 * Update post meta.
	 *
	 * @param string $key     Meta key.
	 * @param mixed  $value   Meta value.
	 * @param int    $post_id Post ID.
	 * @return bool
	 */
	public function update_meta( $key, $value, $post_id = 0 ) {
		if ( ! function_exists( 'update_post_meta' ) ) {
			return false;
		}
		
		$post_id = empty( $post_id ) ? get_the_ID() : $post_id;
		return update_post_meta( $post_id, $key, $value );
	}

	/**
	 * Delete post meta.
	 *
	 * @param string $key     Meta key.
	 * @param int    $post_id Post ID.
	 * @return bool
	 */
	public function delete_meta( $key, $post_id = 0 ) {
		if ( ! function_exists( 'delete_post_meta' ) ) {
			return false;
		}
		
		$post_id = empty( $post_id ) ? get_the_ID() : $post_id;
		return delete_post_meta( $post_id, $key );
	}
}