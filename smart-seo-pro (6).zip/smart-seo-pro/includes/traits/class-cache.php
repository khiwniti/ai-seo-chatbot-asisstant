<?php
/**
 * Cache trait.
 *
 * @package SmartSeoPro
 */

namespace RankMath\Traits;

/**
 * Cache trait.
 */
trait Cache {

	/**
	 * Get cached data.
	 *
	 * @param string $key Cache key.
	 * @return mixed
	 */
	public function get_cache( $key ) {
		if ( function_exists( 'wp_cache_get' ) ) {
			return wp_cache_get( $key, 'smart_seo_pro' );
		}
		return false;
	}

	/**
	 * Set cached data.
	 *
	 * @param string $key    Cache key.
	 * @param mixed  $data   Data to cache.
	 * @param int    $expire Expiration time.
	 * @return bool
	 */
	public function set_cache( $key, $data, $expire = 3600 ) {
		if ( function_exists( 'wp_cache_set' ) ) {
			return wp_cache_set( $key, $data, 'smart_seo_pro', $expire );
		}
		return false;
	}

	/**
	 * Delete cached data.
	 *
	 * @param string $key Cache key.
	 * @return bool
	 */
	public function delete_cache( $key ) {
		if ( function_exists( 'wp_cache_delete' ) ) {
			return wp_cache_delete( $key, 'smart_seo_pro' );
		}
		return false;
	}

	/**
	 * Flush cache group.
	 *
	 * @return bool
	 */
	public function flush_cache() {
		if ( function_exists( 'wp_cache_flush_group' ) ) {
			return wp_cache_flush_group( 'smart_seo_pro' );
		}
		return false;
	}
}