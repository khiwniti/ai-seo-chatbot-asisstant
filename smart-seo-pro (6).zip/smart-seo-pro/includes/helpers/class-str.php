<?php
/**
 * String helper.
 *
 * @package SmartSeoPro
 */

namespace RankMath\Helpers;

/**
 * String helper class.
 */
class Str {

	/**
	 * Convert string to slug.
	 *
	 * @param string $string String to convert.
	 * @return string
	 */
	public static function slug( $string ) {
		if ( function_exists( 'sanitize_title' ) ) {
			return sanitize_title( $string );
		}
		
		return strtolower( preg_replace( '/[^a-zA-Z0-9-_]/', '-', $string ) );
	}

	/**
	 * Check if string starts with.
	 *
	 * @param string $haystack String to search in.
	 * @param string $needle   String to search for.
	 * @return bool
	 */
	public static function starts_with( $haystack, $needle ) {
		return substr( $haystack, 0, strlen( $needle ) ) === $needle;
	}

	/**
	 * Check if string ends with.
	 *
	 * @param string $haystack String to search in.
	 * @param string $needle   String to search for.
	 * @return bool
	 */
	public static function ends_with( $haystack, $needle ) {
		return substr( $haystack, -strlen( $needle ) ) === $needle;
	}

	/**
	 * Check if string contains.
	 *
	 * @param string $haystack String to search in.
	 * @param string $needle   String to search for.
	 * @return bool
	 */
	public static function contains( $haystack, $needle ) {
		return strpos( $haystack, $needle ) !== false;
	}

	/**
	 * Truncate string.
	 *
	 * @param string $string String to truncate.
	 * @param int    $length Maximum length.
	 * @param string $suffix Suffix to add.
	 * @return string
	 */
	public static function truncate( $string, $length = 100, $suffix = '...' ) {
		if ( strlen( $string ) <= $length ) {
			return $string;
		}

		return substr( $string, 0, $length ) . $suffix;
	}

	/**
	 * Convert to camel case.
	 *
	 * @param string $string String to convert.
	 * @return string
	 */
	public static function camel( $string ) {
		return lcfirst( str_replace( ' ', '', ucwords( str_replace( [ '-', '_' ], ' ', $string ) ) ) );
	}

	/**
	 * Convert to snake case.
	 *
	 * @param string $string String to convert.
	 * @return string
	 */
	public static function snake( $string ) {
		return strtolower( preg_replace( '/(?<!^)[A-Z]/', '_$0', $string ) );
	}
}