<?php
/**
 * Smart SEO Pro Configuration Example
 * 
 * Copy this file to config.php and update with your API keys
 * 
 * @since 1.0.0
 */

// Prevent direct access
defined( 'ABSPATH' ) || exit;

/**
 * OpenAI Configuration
 * Required for content generation
 */
define( 'SMART_SEO_OPENAI_API_KEY', 'sk-your-openai-api-key-here' );

/**
 * Google Search Console Configuration
 * Optional - for enhanced keyword research
 */
define( 'SMART_SEO_GSC_API_KEY', 'your-google-search-console-api-key' );
define( 'SMART_SEO_GSC_SITE_URL', 'https://yourwebsite.com' );

/**
 * Ahrefs Configuration
 * Optional - for advanced keyword research
 */
define( 'SMART_SEO_AHREFS_API_KEY', 'your-ahrefs-api-key' );

/**
 * Default Content Generation Settings
 */
define( 'SMART_SEO_DEFAULT_LANGUAGE', 'en' ); // en, th, es, fr, de, it, pt
define( 'SMART_SEO_DEFAULT_CONTENT_TYPE', 'blog_post' );
define( 'SMART_SEO_DEFAULT_WORD_COUNT', 1500 );

/**
 * Performance Settings
 */
define( 'SMART_SEO_MAX_EXECUTION_TIME', 300 ); // 5 minutes
define( 'SMART_SEO_MEMORY_LIMIT', '512M' );

/**
 * Debug Settings
 */
define( 'SMART_SEO_DEBUG', false );
define( 'SMART_SEO_LOG_LEVEL', 'error' ); // error, warning, info, debug

/**
 * Business Information Template
 * Customize this for your business
 */
$smart_seo_business_config = [
    'name' => 'Your Business Name',
    'industry' => 'Your Industry',
    'target_audience' => 'Your Target Audience',
    'products' => [
        'Product 1',
        'Product 2',
        'Product 3'
    ],
    'services' => [
        'Service 1',
        'Service 2',
        'Service 3'
    ],
    'channels' => [
        'website' => 'https://yourwebsite.com',
        'shopee' => 'https://shopee.com/yourstore',
        'lazada' => 'https://lazada.com/yourstore',
        'facebook' => 'https://facebook.com/yourpage',
        'instagram' => 'https://instagram.com/youraccount'
    ],
    'contact' => [
        'email' => 'contact@yourwebsite.com',
        'phone' => '+1234567890',
        'address' => 'Your Business Address'
    ]
];

/**
 * Content Templates
 * Customize content generation templates
 */
$smart_seo_content_templates = [
    'blog_post' => [
        'min_word_count' => 800,
        'max_word_count' => 2500,
        'sections' => 6,
        'include_faq' => true,
        'include_conclusion' => true
    ],
    'product_page' => [
        'min_word_count' => 500,
        'max_word_count' => 1500,
        'sections' => 4,
        'include_features' => true,
        'include_benefits' => true,
        'include_specifications' => true
    ],
    'service_page' => [
        'min_word_count' => 600,
        'max_word_count' => 1800,
        'sections' => 5,
        'include_process' => true,
        'include_pricing' => true,
        'include_testimonials' => true
    ]
];

/**
 * SEO Settings
 */
$smart_seo_settings = [
    'keyword_density' => [
        'min' => 0.5,
        'max' => 3.0,
        'optimal' => 1.5
    ],
    'readability' => [
        'target_score' => 60,
        'min_score' => 40
    ],
    'meta_description' => [
        'min_length' => 140,
        'max_length' => 160
    ],
    'title' => [
        'min_length' => 30,
        'max_length' => 60
    ]
];

/**
 * Apply configuration if config.php exists
 */
if ( file_exists( __DIR__ . '/config.php' ) ) {
    require_once __DIR__ . '/config.php';
}

/**
 * Set WordPress options from constants
 */
add_action( 'init', function() {
    if ( defined( 'SMART_SEO_OPENAI_API_KEY' ) ) {
        update_option( 'smart_seo_openai_api_key', SMART_SEO_OPENAI_API_KEY );
    }
    
    if ( defined( 'SMART_SEO_GSC_API_KEY' ) ) {
        update_option( 'smart_seo_gsc_api_key', SMART_SEO_GSC_API_KEY );
    }
    
    if ( defined( 'SMART_SEO_GSC_SITE_URL' ) ) {
        update_option( 'smart_seo_gsc_site_url', SMART_SEO_GSC_SITE_URL );
    }
    
    if ( defined( 'SMART_SEO_AHREFS_API_KEY' ) ) {
        update_option( 'smart_seo_ahrefs_api_key', SMART_SEO_AHREFS_API_KEY );
    }
    
    // Store business configuration
    global $smart_seo_business_config, $smart_seo_content_templates, $smart_seo_settings;
    
    if ( isset( $smart_seo_business_config ) ) {
        update_option( 'smart_seo_business_config', $smart_seo_business_config );
    }
    
    if ( isset( $smart_seo_content_templates ) ) {
        update_option( 'smart_seo_content_templates', $smart_seo_content_templates );
    }
    
    if ( isset( $smart_seo_settings ) ) {
        update_option( 'smart_seo_settings', $smart_seo_settings );
    }
} );