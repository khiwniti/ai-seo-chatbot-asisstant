/**
 * Smart SEO Pro Content Generator
 * 
 * @since 1.0.0
 */

(function($) {
    'use strict';

    const SmartSeoContentGenerator = {
        
        init: function() {
            this.bindEvents();
            this.initializeInterface();
        },

        bindEvents: function() {
            $(document).on('click', '.smart-seo-generate-content', this.generateFullContent);
            $(document).on('click', '.smart-seo-find-keywords', this.findKeywords);
            $(document).on('click', '.smart-seo-generate-outline', this.generateOutline);
            $(document).on('click', '.smart-seo-generate-media', this.generateMedia);
            $(document).on('click', '.smart-seo-publish-content', this.publishContent);
            $(document).on('change', '#smart-seo-keyword-input', this.onKeywordChange);
        },

        initializeInterface: function() {
            if ($('#smart-seo-content-generator').length === 0 && $('#smart-seo-content-generator-admin').length === 0) {
                this.createInterface();
            } else if ($('#smart-seo-content-generator-admin').length > 0) {
                this.createAdminInterface();
            }
        },

        createInterface: function() {
            const interfaceHTML = `
                <div id="smart-seo-content-generator" class="smart-seo-panel">
                    <div class="smart-seo-header">
                        <h2>🤖 AI Content Generator</h2>
                        <p>Generate SEO-optimized content with our 6-agent system</p>
                    </div>
                    
                    <div class="smart-seo-form">
                        <div class="smart-seo-field">
                            <label for="smart-seo-keyword-input">Primary Keyword</label>
                            <input type="text" id="smart-seo-keyword-input" placeholder="Enter your target keyword..." />
                        </div>
                        
                        <div class="smart-seo-field">
                            <label for="smart-seo-content-type">Content Type</label>
                            <select id="smart-seo-content-type">
                                <option value="blog_post">Blog Post</option>
                                <option value="how_to_guide">How-to Guide</option>
                                <option value="product_page">Product Page</option>
                                <option value="service_page">Service Page</option>
                                <option value="comparison">Comparison</option>
                                <option value="review">Review</option>
                            </select>
                        </div>
                        
                        <div class="smart-seo-field">
                            <label for="smart-seo-language">Language</label>
                            <select id="smart-seo-language">
                                <option value="en">English</option>
                                <option value="th">ไทย (Thai)</option>
                                <option value="es">Español</option>
                                <option value="fr">Français</option>
                                <option value="de">Deutsch</option>
                                <option value="it">Italiano</option>
                                <option value="pt">Português</option>
                            </select>
                        </div>
                        
                        <div class="smart-seo-actions">
                            <button class="smart-seo-btn smart-seo-btn-primary smart-seo-generate-content">
                                🚀 Generate Complete Content
                            </button>
                            <button class="smart-seo-btn smart-seo-find-keywords">
                                🔍 Find Keywords Only
                            </button>
                        </div>
                    </div>
                    
                    <div class="smart-seo-progress" style="display: none;">
                        <div class="smart-seo-progress-bar">
                            <div class="smart-seo-progress-fill"></div>
                        </div>
                        <div class="smart-seo-progress-text">Initializing...</div>
                    </div>
                    
                    <div class="smart-seo-results" style="display: none;">
                        <div class="smart-seo-tabs">
                            <button class="smart-seo-tab active" data-tab="content">📝 Content</button>
                            <button class="smart-seo-tab" data-tab="keywords">🔑 Keywords</button>
                            <button class="smart-seo-tab" data-tab="seo">📊 SEO Analysis</button>
                            <button class="smart-seo-tab" data-tab="media">🖼️ Media</button>
                        </div>
                        
                        <div class="smart-seo-tab-content" id="smart-seo-tab-content">
                            <div class="smart-seo-content-preview"></div>
                            <div class="smart-seo-content-actions">
                                <button class="smart-seo-btn smart-seo-publish-content">📤 Publish as Draft</button>
                                <button class="smart-seo-btn smart-seo-copy-content">📋 Copy Content</button>
                            </div>
                        </div>
                        
                        <div class="smart-seo-tab-content" id="smart-seo-tab-keywords" style="display: none;">
                            <div class="smart-seo-keywords-list"></div>
                        </div>
                        
                        <div class="smart-seo-tab-content" id="smart-seo-tab-seo" style="display: none;">
                            <div class="smart-seo-seo-analysis"></div>
                        </div>
                        
                        <div class="smart-seo-tab-content" id="smart-seo-tab-media" style="display: none;">
                            <div class="smart-seo-media-gallery"></div>
                        </div>
                    </div>
                </div>
            `;

            // Insert after post title or at the beginning of content area
            if ($('#title').length) {
                $('#title').after(interfaceHTML);
            } else if ($('#post-body-content').length) {
                $('#post-body-content').prepend(interfaceHTML);
            } else {
                $('body').append(interfaceHTML);
            }

            // Bind tab switching
            $(document).on('click', '.smart-seo-tab', this.switchTab);
        },

        createAdminInterface: function() {
            const interfaceHTML = `
                <div id="smart-seo-content-generator" class="smart-seo-panel">
                    <div class="smart-seo-header">
                        <h2>🚀 AI Content Generator</h2>
                        <p>Generate high-quality, SEO-optimized content with AI</p>
                    </div>
                    
                    <div class="smart-seo-form">
                        <div class="smart-seo-input-group">
                            <label for="smart-seo-keyword-input">Target Keyword</label>
                            <input type="text" id="smart-seo-keyword-input" placeholder="Enter your target keyword..." />
                        </div>
                        
                        <div class="smart-seo-input-row">
                            <div class="smart-seo-input-group">
                                <label for="smart-seo-content-type">Content Type</label>
                                <select id="smart-seo-content-type">
                                    <option value="blog_post">Blog Post</option>
                                    <option value="product_description">Product Description</option>
                                    <option value="landing_page">Landing Page</option>
                                    <option value="article">Article</option>
                                </select>
                            </div>
                            
                            <div class="smart-seo-input-group">
                                <label for="smart-seo-language">Language</label>
                                <select id="smart-seo-language">
                                    <option value="en">English</option>
                                    <option value="th">Thai</option>
                                    <option value="es">Spanish</option>
                                    <option value="fr">French</option>
                                    <option value="de">German</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="smart-seo-buttons">
                            <button type="button" class="smart-seo-btn smart-seo-btn-primary smart-seo-generate-content">
                                🎯 Generate Complete Content
                            </button>
                            <button type="button" class="smart-seo-btn smart-seo-find-keywords">
                                🔍 Find Keywords Only
                            </button>
                            <button type="button" class="smart-seo-btn smart-seo-generate-outline">
                                📝 Generate Outline Only
                            </button>
                        </div>
                    </div>
                    
                    <div id="smart-seo-progress" class="smart-seo-progress" style="display: none;">
                        <div class="smart-seo-progress-bar">
                            <div class="smart-seo-progress-fill"></div>
                        </div>
                        <div class="smart-seo-progress-text">Initializing...</div>
                    </div>
                    
                    <div id="smart-seo-results" class="smart-seo-results" style="display: none;">
                        <div class="smart-seo-tabs">
                            <button class="smart-seo-tab active" data-tab="content">📄 Content</button>
                            <button class="smart-seo-tab" data-tab="keywords">🔑 Keywords</button>
                            <button class="smart-seo-tab" data-tab="outline">📋 Outline</button>
                            <button class="smart-seo-tab" data-tab="media">🖼️ Media</button>
                        </div>
                        
                        <div class="smart-seo-tab-content">
                            <div id="smart-seo-tab-content" class="smart-seo-tab-panel active">
                                <div class="smart-seo-content-preview"></div>
                                <div class="smart-seo-content-actions">
                                    <button type="button" class="smart-seo-btn smart-seo-publish-content">
                                        📤 Publish to WordPress
                                    </button>
                                    <button type="button" class="smart-seo-btn smart-seo-copy-content">
                                        📋 Copy to Clipboard
                                    </button>
                                </div>
                            </div>
                            
                            <div id="smart-seo-tab-keywords" class="smart-seo-tab-panel">
                                <div class="smart-seo-keywords-list"></div>
                            </div>
                            
                            <div id="smart-seo-tab-outline" class="smart-seo-tab-panel">
                                <div class="smart-seo-outline-preview"></div>
                            </div>
                            
                            <div id="smart-seo-tab-media" class="smart-seo-tab-panel">
                                <div class="smart-seo-media-gallery"></div>
                                <button type="button" class="smart-seo-btn smart-seo-generate-media">
                                    🎨 Generate More Images
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            $('#smart-seo-content-generator-admin').html(interfaceHTML);
        },

        generateFullContent: function(e) {
            e.preventDefault();
            
            const keyword = $('#smart-seo-keyword-input').val().trim();
            const contentType = $('#smart-seo-content-type').val();
            const language = $('#smart-seo-language').val();

            if (!keyword) {
                alert('Please enter a keyword first.');
                return;
            }

            SmartSeoContentGenerator.showProgress();
            SmartSeoContentGenerator.updateProgress(0, 'Starting content generation...');

            const data = {
                action: 'smart_seo_generate_content',
                nonce: smartSeoContentGenerator.nonce,
                keyword: keyword,
                content_type: contentType,
                language: language
            };

            // Simulate progress updates
            let progress = 0;
            const progressInterval = setInterval(() => {
                progress += Math.random() * 15;
                if (progress > 90) progress = 90;
                
                let message = 'Generating content...';
                if (progress < 20) message = '🔍 Agent 1: Finding keywords...';
                else if (progress < 40) message = '📋 Agent 2: Creating outline...';
                else if (progress < 60) message = '✍️ Agent 3: Writing content...';
                else if (progress < 80) message = '🔧 Agent 4: Optimizing SEO...';
                else if (progress < 90) message = '🖼️ Agent 5: Generating media...';
                
                SmartSeoContentGenerator.updateProgress(progress, message);
            }, 1000);

            $.ajax({
                url: smartSeoContentGenerator.ajaxUrl,
                type: 'POST',
                data: data,
                timeout: 300000, // 5 minutes
                success: function(response) {
                    clearInterval(progressInterval);
                    SmartSeoContentGenerator.updateProgress(100, '✅ Content generation complete!');
                    
                    setTimeout(() => {
                        SmartSeoContentGenerator.hideProgress();
                        if (response.success) {
                            SmartSeoContentGenerator.displayResults(response.data);
                        } else {
                            alert('Error: ' + (response.data || 'Unknown error occurred'));
                        }
                    }, 1000);
                },
                error: function(xhr, status, error) {
                    clearInterval(progressInterval);
                    SmartSeoContentGenerator.hideProgress();
                    console.error('AJAX Error:', error);
                    alert('Error generating content: ' + error);
                }
            });
        },

        findKeywords: function(e) {
            e.preventDefault();
            
            const keyword = $('#smart-seo-keyword-input').val().trim();

            if (!keyword) {
                alert('Please enter a keyword first.');
                return;
            }

            SmartSeoContentGenerator.showProgress();
            SmartSeoContentGenerator.updateProgress(50, '🔍 Finding keywords...');

            const data = {
                action: 'smart_seo_get_keywords',
                nonce: smartSeoContentGenerator.nonce,
                keyword: keyword
            };

            $.ajax({
                url: smartSeoContentGenerator.ajaxUrl,
                type: 'POST',
                data: data,
                success: function(response) {
                    SmartSeoContentGenerator.updateProgress(100, '✅ Keywords found!');
                    
                    setTimeout(() => {
                        SmartSeoContentGenerator.hideProgress();
                        if (response.success) {
                            SmartSeoContentGenerator.displayKeywords(response.data);
                        } else {
                            alert('Error: ' + (response.data || 'Unknown error occurred'));
                        }
                    }, 500);
                },
                error: function(xhr, status, error) {
                    SmartSeoContentGenerator.hideProgress();
                    alert('Error finding keywords: ' + error);
                }
            });
        },

        displayResults: function(data) {
            $('.smart-seo-results').show();
            
            // Display content
            if (data.content) {
                this.displayContent(data.content);
            }
            
            // Display keywords
            if (data.keywords) {
                this.displayKeywords(data.keywords);
            }
            
            // Display SEO analysis
            if (data.content) {
                this.displaySeoAnalysis(data.content);
            }
            
            // Display media
            if (data.media) {
                this.displayMedia(data.media);
            }

            // Store data for publishing
            $('#smart-seo-content-generator').data('generated-content', data);
        },

        displayContent: function(content) {
            const contentHtml = `
                <div class="smart-seo-content-item">
                    <h3>📝 Generated Content</h3>
                    <div class="smart-seo-meta-info">
                        <span><strong>Title:</strong> ${content.title}</span>
                        <span><strong>Word Count:</strong> ${content.keyword_analysis?.word_count || 'N/A'}</span>
                        <span><strong>SEO Score:</strong> ${content.seo_score || 'N/A'}/100</span>
                    </div>
                    <div class="smart-seo-content-body">
                        <h4>Meta Description:</h4>
                        <p class="smart-seo-meta-desc">${content.meta_description}</p>
                        
                        <h4>Content Preview:</h4>
                        <div class="smart-seo-content-preview-body">
                            ${content.full_html}
                        </div>
                    </div>
                </div>
            `;
            
            $('.smart-seo-content-preview').html(contentHtml);
        },

        generateOutline: function(e) {
            e.preventDefault();
            
            const keyword = $('#smart-seo-keyword-input').val().trim();
            const contentType = $('#smart-seo-content-type').val();
            const language = $('#smart-seo-language').val();

            if (!keyword) {
                alert('Please enter a keyword first.');
                return;
            }

            SmartSeoContentGenerator.showProgress();
            SmartSeoContentGenerator.updateProgress(50, '📝 Generating outline...');

            const data = {
                action: 'smart_seo_generate_outline',
                nonce: smartSeoContentGenerator.nonce,
                keyword: keyword,
                content_type: contentType,
                language: language
            };

            $.ajax({
                url: smartSeoContentGenerator.ajaxUrl,
                type: 'POST',
                data: data,
                success: function(response) {
                    SmartSeoContentGenerator.hideProgress();
                    
                    if (response.success) {
                        SmartSeoContentGenerator.displayOutline(response.data.outline);
                        $('#smart-seo-content-generator').data('generated-outline', response.data);
                    } else {
                        alert('Error: ' + (response.data || 'Failed to generate outline'));
                    }
                },
                error: function() {
                    SmartSeoContentGenerator.hideProgress();
                    alert('Network error occurred while generating outline.');
                }
            });
        },

        generateMedia: function(e) {
            e.preventDefault();
            
            const keyword = $('#smart-seo-keyword-input').val().trim();
            const contentType = $('#smart-seo-content-type').val();

            if (!keyword) {
                alert('Please enter a keyword first.');
                return;
            }

            SmartSeoContentGenerator.showProgress();
            SmartSeoContentGenerator.updateProgress(75, '🎨 Generating media...');

            const data = {
                action: 'smart_seo_generate_media',
                nonce: smartSeoContentGenerator.nonce,
                keyword: keyword,
                content_type: contentType
            };

            $.ajax({
                url: smartSeoContentGenerator.ajaxUrl,
                type: 'POST',
                data: data,
                success: function(response) {
                    SmartSeoContentGenerator.hideProgress();
                    
                    if (response.success) {
                        SmartSeoContentGenerator.displayMedia(response.data.media);
                        $('#smart-seo-content-generator').data('generated-media', response.data);
                        $('.smart-seo-results').show();
                        SmartSeoContentGenerator.switchTabTo('media');
                    } else {
                        alert('Error: ' + (response.data || 'Failed to generate media'));
                    }
                },
                error: function() {
                    SmartSeoContentGenerator.hideProgress();
                    alert('Network error occurred while generating media.');
                }
            });
        },

        displayOutline: function(outline) {
            let outlineHtml = '<div class="smart-seo-outline-section">';
            
            if (outline.title) {
                outlineHtml += `<h3>📝 ${outline.title}</h3>`;
            }
            
            if (outline.meta_description) {
                outlineHtml += `
                    <div class="smart-seo-meta-description">
                        <h4>📄 Meta Description</h4>
                        <p>${outline.meta_description}</p>
                    </div>
                `;
            }
            
            if (outline.structure && outline.structure.length > 0) {
                outlineHtml += '<div class="smart-seo-outline-structure"><h4>📋 Content Structure</h4><ul>';
                outline.structure.forEach(item => {
                    const level = item.level || 'h2';
                    const indent = level === 'h3' ? 'style="margin-left: 20px;"' : level === 'h4' ? 'style="margin-left: 40px;"' : '';
                    outlineHtml += `<li ${indent}><strong>${level.toUpperCase()}:</strong> ${item.title}`;
                    if (item.description) {
                        outlineHtml += `<br><small>${item.description}</small>`;
                    }
                    outlineHtml += '</li>';
                });
                outlineHtml += '</ul></div>';
            }
            
            if (outline.keywords_to_include && outline.keywords_to_include.length > 0) {
                outlineHtml += `
                    <div class="smart-seo-outline-keywords">
                        <h4>🔑 Keywords to Include</h4>
                        <div class="smart-seo-keyword-list">
                `;
                outline.keywords_to_include.forEach(kw => {
                    outlineHtml += `<span class="smart-seo-keyword">${kw}</span>`;
                });
                outlineHtml += '</div></div>';
            }
            
            outlineHtml += '</div>';
            $('.smart-seo-outline-preview').html(outlineHtml);
            
            // Show results and switch to outline tab
            $('.smart-seo-results').show();
            this.switchTabTo('outline');
        },

        displayKeywords: function(keywords) {
            let keywordsHtml = '<div class="smart-seo-keywords-section">';
            
            // Primary keyword
            keywordsHtml += `
                <div class="smart-seo-keyword-group">
                    <h4>🎯 Primary Keyword</h4>
                    <span class="smart-seo-keyword smart-seo-keyword-primary">${keywords.primary}</span>
                </div>
            `;
            
            // LSI keywords
            if (keywords.lsi && keywords.lsi.length > 0) {
                keywordsHtml += `
                    <div class="smart-seo-keyword-group">
                        <h4>🔗 LSI Keywords</h4>
                        <div class="smart-seo-keyword-list">
                `;
                keywords.lsi.forEach(kw => {
                    const keyword = typeof kw === 'object' ? kw.keyword : kw;
                    keywordsHtml += `<span class="smart-seo-keyword smart-seo-keyword-lsi">${keyword}</span>`;
                });
                keywordsHtml += '</div></div>';
            }
            
            // Related keywords
            if (keywords.related && keywords.related.length > 0) {
                keywordsHtml += `
                    <div class="smart-seo-keyword-group">
                        <h4>🔄 Related Keywords</h4>
                        <div class="smart-seo-keyword-list">
                `;
                keywords.related.slice(0, 10).forEach(kw => {
                    const keyword = typeof kw === 'object' ? kw.keyword : kw;
                    keywordsHtml += `<span class="smart-seo-keyword smart-seo-keyword-related">${keyword}</span>`;
                });
                keywordsHtml += '</div></div>';
            }
            
            // Long-tail keywords
            if (keywords.long_tail && keywords.long_tail.length > 0) {
                keywordsHtml += `
                    <div class="smart-seo-keyword-group">
                        <h4>📏 Long-tail Keywords</h4>
                        <div class="smart-seo-keyword-list">
                `;
                keywords.long_tail.forEach(kw => {
                    const keyword = typeof kw === 'object' ? kw.keyword : kw;
                    keywordsHtml += `<span class="smart-seo-keyword smart-seo-keyword-longtail">${keyword}</span>`;
                });
                keywordsHtml += '</div></div>';
            }
            
            keywordsHtml += '</div>';
            $('.smart-seo-keywords-list').html(keywordsHtml);
            
            // Show results and switch to keywords tab
            $('.smart-seo-results').show();
            this.switchTabTo('keywords');
        },

        displaySeoAnalysis: function(content) {
            const analysis = content.keyword_analysis || {};
            const readability = content.readability || {};
            const recommendations = content.seo_recommendations || [];
            
            let analysisHtml = `
                <div class="smart-seo-analysis-section">
                    <div class="smart-seo-score-card">
                        <h3>📊 SEO Score: ${content.seo_score || 0}/100</h3>
                        <div class="smart-seo-score-bar">
                            <div class="smart-seo-score-fill" style="width: ${content.seo_score || 0}%"></div>
                        </div>
                    </div>
                    
                    <div class="smart-seo-metrics">
                        <div class="smart-seo-metric">
                            <h4>📝 Content Metrics</h4>
                            <ul>
                                <li>Word Count: ${analysis.word_count || 'N/A'}</li>
                                <li>Primary Keyword Density: ${analysis.primary_keyword?.density?.toFixed(2) || 0}%</li>
                                <li>Readability Score: ${readability.score || 'N/A'} (${readability.level || 'Unknown'})</li>
                            </ul>
                        </div>
                        
                        <div class="smart-seo-metric">
                            <h4>🔍 Keyword Analysis</h4>
                            <ul>
                                <li>Primary Keyword: "${analysis.primary_keyword?.keyword || 'N/A'}"</li>
                                <li>Keyword Count: ${analysis.primary_keyword?.count || 0}</li>
                                <li>Status: ${this.getStatusBadge(analysis.primary_keyword?.status || 'unknown')}</li>
                            </ul>
                        </div>
                    </div>
            `;
            
            if (recommendations.length > 0) {
                analysisHtml += `
                    <div class="smart-seo-recommendations">
                        <h4>💡 SEO Recommendations</h4>
                        <ul>
                `;
                recommendations.forEach(rec => {
                    const icon = rec.type === 'warning' ? '⚠️' : rec.type === 'error' ? '❌' : 'ℹ️';
                    analysisHtml += `<li class="smart-seo-rec-${rec.type}">${icon} ${rec.message}</li>`;
                });
                analysisHtml += '</ul></div>';
            }
            
            analysisHtml += '</div>';
            $('.smart-seo-seo-analysis').html(analysisHtml);
        },

        displayMedia: function(media) {
            let mediaHtml = '<div class="smart-seo-media-section">';
            
            if (media.featured_image) {
                mediaHtml += `
                    <div class="smart-seo-media-item">
                        <h4>🖼️ Featured Image</h4>
                        <img src="${media.featured_image.url}" alt="${media.featured_image.alt_text}" style="max-width: 300px;" />
                        <p><strong>Alt Text:</strong> ${media.featured_image.alt_text}</p>
                        <p><strong>Caption:</strong> ${media.featured_image.caption}</p>
                    </div>
                `;
            }
            
            if (media.content_images && media.content_images.length > 0) {
                mediaHtml += '<div class="smart-seo-content-images"><h4>📷 Content Images</h4>';
                media.content_images.forEach(img => {
                    mediaHtml += `
                        <div class="smart-seo-media-item">
                            <img src="${img.url}" alt="${img.alt_text}" style="max-width: 200px;" />
                            <p><strong>Type:</strong> ${img.type}</p>
                            <p><strong>Alt Text:</strong> ${img.alt_text}</p>
                        </div>
                    `;
                });
                mediaHtml += '</div>';
            }
            
            if (!media.featured_image && (!media.content_images || media.content_images.length === 0)) {
                mediaHtml += '<p>No media was generated for this content.</p>';
            }
            
            mediaHtml += '</div>';
            $('.smart-seo-media-gallery').html(mediaHtml);
        },

        getStatusBadge: function(status) {
            const badges = {
                'good': '<span class="smart-seo-badge smart-seo-badge-good">✅ Good</span>',
                'warning': '<span class="smart-seo-badge smart-seo-badge-warning">⚠️ Warning</span>',
                'error': '<span class="smart-seo-badge smart-seo-badge-error">❌ Error</span>',
                'low': '<span class="smart-seo-badge smart-seo-badge-warning">📉 Low</span>',
                'high': '<span class="smart-seo-badge smart-seo-badge-warning">📈 High</span>',
                'missing': '<span class="smart-seo-badge smart-seo-badge-error">❌ Missing</span>'
            };
            return badges[status] || '<span class="smart-seo-badge">❓ Unknown</span>';
        },

        switchTab: function(e) {
            e.preventDefault();
            const tab = $(this).data('tab');
            SmartSeoContentGenerator.switchTabTo(tab);
        },

        switchTabTo: function(tab) {
            $('.smart-seo-tab').removeClass('active');
            $(`.smart-seo-tab[data-tab="${tab}"]`).addClass('active');
            
            $('.smart-seo-tab-content').hide();
            $(`#smart-seo-tab-${tab}`).show();
        },

        showProgress: function() {
            $('.smart-seo-form').hide();
            $('.smart-seo-progress').show();
        },

        hideProgress: function() {
            $('.smart-seo-progress').hide();
            $('.smart-seo-form').show();
        },

        updateProgress: function(percent, message) {
            $('.smart-seo-progress-fill').css('width', percent + '%');
            $('.smart-seo-progress-text').text(message);
        },

        publishContent: function(e) {
            e.preventDefault();
            
            const generatedData = $('#smart-seo-content-generator').data('generated-content');
            if (!generatedData) {
                alert('No content to publish. Please generate content first.');
                return;
            }

            if (confirm('This will create a new draft post with the generated content. Continue?')) {
                // Here you would implement the publishing logic
                // For now, we'll just copy the content to the editor if available
                if (typeof tinymce !== 'undefined' && tinymce.activeEditor) {
                    tinymce.activeEditor.setContent(generatedData.content.full_html);
                    $('#title').val(generatedData.content.title);
                    alert('Content has been inserted into the editor!');
                } else if ($('#content').length) {
                    $('#content').val(generatedData.content.full_html);
                    $('#title').val(generatedData.content.title);
                    alert('Content has been inserted into the editor!');
                } else {
                    alert('Content generated successfully! Use the copy button to get the content.');
                }
            }
        },

        onKeywordChange: function() {
            // Clear previous results when keyword changes
            $('.smart-seo-results').hide();
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        SmartSeoContentGenerator.init();
    });

})(jQuery);