<?php
/**
 * Keyword Finder Agent.
 *
 * @since      1.0.0
 * @package    SmartSeo
 * @subpackage SmartSeoPro\ContentGenerator\Agents
 * @author     Smart SEO Team <support@smartseo.dev>
 */

namespace RankMathPro\ContentGenerator\Agents;

defined( 'ABSPATH' ) || exit;

/**
 * Keyword_Finder class.
 */
class Keyword_Finder {

	/**
	 * Find keywords using various APIs and methods.
	 *
	 * @param string $primary_keyword Primary keyword.
	 * @return array
	 */
	public function find_keywords( $primary_keyword ) {
		$keywords = [
			'primary' => $primary_keyword,
			'lsi'     => [],
			'related' => [],
			'long_tail' => [],
		];

		// Try Google Search Console API first
		$gsc_keywords = $this->get_gsc_keywords( $primary_keyword );
		if ( ! empty( $gsc_keywords ) ) {
			$keywords['related'] = array_merge( $keywords['related'], $gsc_keywords );
		}

		// Try Ahrefs API if available
		$ahrefs_keywords = $this->get_ahrefs_keywords( $primary_keyword );
		if ( ! empty( $ahrefs_keywords ) ) {
			$keywords['related'] = array_merge( $keywords['related'], $ahrefs_keywords );
		}

		// Generate LSI keywords using OpenAI
		$lsi_keywords = $this->generate_lsi_keywords( $primary_keyword );
		if ( ! empty( $lsi_keywords ) ) {
			$keywords['lsi'] = $lsi_keywords;
		}

		// Generate long-tail keywords
		$long_tail_keywords = $this->generate_long_tail_keywords( $primary_keyword );
		if ( ! empty( $long_tail_keywords ) ) {
			$keywords['long_tail'] = $long_tail_keywords;
		}

		// Remove duplicates and clean up
		$keywords = $this->clean_keywords( $keywords );

		return $keywords;
	}

	/**
	 * Get keywords from Google Search Console API.
	 *
	 * @param string $keyword Primary keyword.
	 * @return array
	 */
	private function get_gsc_keywords( $keyword ) {
		$gsc_api_key = get_option( 'smart_seo_gsc_api_key', '' );
		$gsc_site_url = get_option( 'smart_seo_gsc_site_url', '' );

		if ( empty( $gsc_api_key ) || empty( $gsc_site_url ) ) {
			return [];
		}

		$url = 'https://www.googleapis.com/webmasters/v3/sites/' . urlencode( $gsc_site_url ) . '/searchAnalytics/query';
		
		$body = json_encode( [
			'startDate' => date( 'Y-m-d', strtotime( '-90 days' ) ),
			'endDate'   => date( 'Y-m-d', strtotime( '-1 day' ) ),
			'dimensions' => [ 'query' ],
			'dimensionFilterGroups' => [
				[
					'filters' => [
						[
							'dimension' => 'query',
							'operator'  => 'contains',
							'expression' => $keyword,
						],
					],
				],
			],
			'rowLimit' => 50,
		] );

		$response = wp_remote_post( $url, [
			'headers' => [
				'Authorization' => 'Bearer ' . $gsc_api_key,
				'Content-Type'  => 'application/json',
			],
			'body' => $body,
			'timeout' => 30,
		] );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		
		if ( empty( $data['rows'] ) ) {
			return [];
		}

		$keywords = [];
		foreach ( $data['rows'] as $row ) {
			if ( ! empty( $row['keys'][0] ) ) {
				$keywords[] = [
					'keyword' => $row['keys'][0],
					'clicks'  => $row['clicks'] ?? 0,
					'impressions' => $row['impressions'] ?? 0,
					'ctr'     => $row['ctr'] ?? 0,
					'position' => $row['position'] ?? 0,
				];
			}
		}

		return $keywords;
	}

	/**
	 * Get keywords from Ahrefs API.
	 *
	 * @param string $keyword Primary keyword.
	 * @return array
	 */
	private function get_ahrefs_keywords( $keyword ) {
		$ahrefs_api_key = get_option( 'smart_seo_ahrefs_api_key', '' );

		if ( empty( $ahrefs_api_key ) ) {
			return [];
		}

		$url = 'https://apiv2.ahrefs.com/';
		
		$params = [
			'token'  => $ahrefs_api_key,
			'from'   => 'keywords_explorer',
			'target' => $keyword,
			'mode'   => 'phrase',
			'limit'  => 50,
			'select' => 'keyword,volume,difficulty,cpc',
		];

		$response = wp_remote_get( $url . '?' . http_build_query( $params ), [
			'timeout' => 30,
		] );

		if ( is_wp_error( $response ) ) {
			return [];
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		
		if ( empty( $data['keywords'] ) ) {
			return [];
		}

		$keywords = [];
		foreach ( $data['keywords'] as $kw ) {
			$keywords[] = [
				'keyword'    => $kw['keyword'],
				'volume'     => $kw['volume'] ?? 0,
				'difficulty' => $kw['difficulty'] ?? 0,
				'cpc'        => $kw['cpc'] ?? 0,
			];
		}

		return $keywords;
	}

	/**
	 * Generate LSI keywords using OpenAI.
	 *
	 * @param string $keyword Primary keyword.
	 * @return array
	 */
	private function generate_lsi_keywords( $keyword ) {
		$openai_api_key = get_option( 'smart_seo_openai_api_key', '' );

		if ( empty( $openai_api_key ) ) {
			return [];
		}

		$prompt = "Generate 20 LSI (Latent Semantic Indexing) keywords related to '{$keyword}'. These should be semantically related terms that would naturally appear in content about this topic. Return only the keywords, one per line, without numbers or bullets.";

		$response = $this->call_openai_api( $openai_api_key, $prompt );

		if ( empty( $response ) ) {
			return [];
		}

		$keywords = array_filter( array_map( 'trim', explode( "\n", $response ) ) );
		
		return array_slice( $keywords, 0, 20 );
	}

	/**
	 * Generate long-tail keywords.
	 *
	 * @param string $keyword Primary keyword.
	 * @return array
	 */
	private function generate_long_tail_keywords( $keyword ) {
		$openai_api_key = get_option( 'smart_seo_openai_api_key', '' );

		if ( empty( $openai_api_key ) ) {
			return [];
		}

		$prompt = "Generate 15 long-tail keywords (3-5 words each) related to '{$keyword}'. These should be specific phrases that people might search for. Return only the keywords, one per line, without numbers or bullets.";

		$response = $this->call_openai_api( $openai_api_key, $prompt );

		if ( empty( $response ) ) {
			return [];
		}

		$keywords = array_filter( array_map( 'trim', explode( "\n", $response ) ) );
		
		return array_slice( $keywords, 0, 15 );
	}

	/**
	 * Call OpenAI API using cURL.
	 *
	 * @param string $api_key API key.
	 * @param string $prompt Prompt.
	 * @return string
	 */
	private function call_openai_api( $api_key, $prompt ) {
		$payload = [
			"model" => "gpt-4-turbo",
			"messages" => [
				["role" => "system", "content" => "You are an SEO keyword research expert."],
				["role" => "user", "content" => $prompt],
			],
			"temperature" => 0.7,
			"max_tokens" => 500
		];

		$ch = curl_init('https://api.openai.com/v1/chat/completions');
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Content-Type: application/json',
			'Authorization: Bearer ' . $api_key,
		]);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		
		$response = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		if ($response === false || $http_code !== 200) {
			return '';
		}

		$data = json_decode($response, true);
		return $data['choices'][0]['message']['content'] ?? '';
	}

	/**
	 * Get keywords using cURL for GSC API.
	 *
	 * @param string $keyword Primary keyword.
	 * @return array
	 */
	private function get_gsc_keywords_curl( $keyword ) {
		$gsc_api_key = get_option( 'smart_seo_gsc_api_key', '' );
		$gsc_site_url = get_option( 'smart_seo_gsc_site_url', '' );

		if ( empty( $gsc_api_key ) || empty( $gsc_site_url ) ) {
			return [];
		}

		$url = 'https://www.googleapis.com/webmasters/v3/sites/' . urlencode( $gsc_site_url ) . '/searchAnalytics/query';
		
		$payload = [
			'startDate' => date( 'Y-m-d', strtotime( '-90 days' ) ),
			'endDate'   => date( 'Y-m-d', strtotime( '-1 day' ) ),
			'dimensions' => [ 'query' ],
			'dimensionFilterGroups' => [
				[
					'filters' => [
						[
							'dimension' => 'query',
							'operator'  => 'contains',
							'expression' => $keyword,
						],
					],
				],
			],
			'rowLimit' => 50,
		];

		$ch = curl_init($url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Authorization: Bearer ' . $gsc_api_key,
			'Content-Type: application/json',
		]);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 30);
		
		$response = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		if ($response === false || $http_code !== 200) {
			return [];
		}

		$data = json_decode($response, true);
		
		if ( empty( $data['rows'] ) ) {
			return [];
		}

		$keywords = [];
		foreach ( $data['rows'] as $row ) {
			if ( ! empty( $row['keys'][0] ) ) {
				$keywords[] = [
					'keyword' => $row['keys'][0],
					'clicks'  => $row['clicks'] ?? 0,
					'impressions' => $row['impressions'] ?? 0,
					'ctr'     => $row['ctr'] ?? 0,
					'position' => $row['position'] ?? 0,
				];
			}
		}

		return $keywords;
	}

	/**
	 * Clean and deduplicate keywords.
	 *
	 * @param array $keywords Keywords array.
	 * @return array
	 */
	private function clean_keywords( $keywords ) {
		// Remove duplicates from each category
		foreach ( $keywords as $category => &$keyword_list ) {
			if ( $category === 'primary' ) {
				continue;
			}

			if ( is_array( $keyword_list ) ) {
				$unique_keywords = [];
				$seen = [];

				foreach ( $keyword_list as $kw ) {
					$key = is_array( $kw ) ? strtolower( $kw['keyword'] ?? '' ) : strtolower( $kw );
					
					if ( ! empty( $key ) && ! in_array( $key, $seen, true ) ) {
						$seen[] = $key;
						$unique_keywords[] = $kw;
					}
				}

				$keyword_list = $unique_keywords;
			}
		}

		return $keywords;
	}
}