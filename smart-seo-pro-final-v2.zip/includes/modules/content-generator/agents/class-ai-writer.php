<?php
/**
 * AI Writer Agent.
 *
 * @since      1.0.0
 * @package    SmartSeo
 * @subpackage SmartSeoPro\ContentGenerator\Agents
 * @author     Smart SEO Team <support@smartseo.dev>
 */

namespace RankMathPro\ContentGenerator\Agents;

defined( 'ABSPATH' ) || exit;

/**
 * AI_Writer class.
 */
class AI_Writer {

	/**
	 * Generate full content based on outline and keywords.
	 *
	 * @param string $primary_keyword Primary keyword.
	 * @param array  $outline Content outline.
	 * @param array  $keywords All keywords data.
	 * @param string $language Language code.
	 * @return array
	 */
	public function generate_content( $primary_keyword, $outline, $keywords, $language = 'en' ) {
		$openai_api_key = get_option( 'smart_seo_openai_api_key', '' );

		if ( empty( $openai_api_key ) ) {
			throw new \Exception( 'OpenAI API key is required for content generation.' );
		}

		// Generate content in sections for better quality
		$content = [
			'title'       => $outline['title'],
			'meta_description' => $outline['meta_description'],
			'introduction' => $this->generate_introduction( $openai_api_key, $primary_keyword, $outline, $keywords, $language ),
			'sections'    => $this->generate_sections( $openai_api_key, $primary_keyword, $outline, $keywords, $language ),
			'faq'         => $this->generate_faq( $openai_api_key, $primary_keyword, $outline, $keywords, $language ),
			'conclusion'  => $this->generate_conclusion( $openai_api_key, $primary_keyword, $outline, $keywords, $language ),
			'full_html'   => '',
		];

		// Compile full HTML content
		$content['full_html'] = $this->compile_full_content( $content );

		return $content;
	}

	/**
	 * Generate introduction section.
	 *
	 * @param string $api_key OpenAI API key.
	 * @param string $primary_keyword Primary keyword.
	 * @param array  $outline Content outline.
	 * @param array  $keywords Keywords data.
	 * @param string $language Language code.
	 * @return string
	 */
	private function generate_introduction( $api_key, $primary_keyword, $outline, $keywords, $language ) {
		$lsi_keywords = $this->extract_keyword_list( $keywords['lsi'] ?? [] );
		$language_instruction = $this->get_language_instruction( $language );

		$prompt = "Write an engaging introduction for an article about '{$primary_keyword}'.

{$language_instruction}

REQUIREMENTS:
- Hook the reader with an interesting opening
- Naturally include the primary keyword: {$primary_keyword}
- Incorporate 2-3 of these LSI keywords naturally: " . implode( ', ', array_slice( $lsi_keywords, 0, 5 ) ) . "
- Length: 150-200 words
- Use a conversational but professional tone
- End with a preview of what the article will cover

OUTLINE CONTEXT:
Title: {$outline['title']}
Introduction notes: " . implode( ', ', $outline['introduction']['notes'] ?? [] ) . "

Return only the HTML content without any markdown formatting.";

		return $this->call_openai_api( $api_key, $prompt );
	}

	/**
	 * Generate main content sections.
	 *
	 * @param string $api_key OpenAI API key.
	 * @param string $primary_keyword Primary keyword.
	 * @param array  $outline Content outline.
	 * @param array  $keywords Keywords data.
	 * @param string $language Language code.
	 * @return array
	 */
	private function generate_sections( $api_key, $primary_keyword, $outline, $keywords, $language ) {
		$sections = [];
		$lsi_keywords = $this->extract_keyword_list( $keywords['lsi'] ?? [] );
		$related_keywords = $this->extract_keyword_list( $keywords['related'] ?? [] );
		$language_instruction = $this->get_language_instruction( $language );

		foreach ( $outline['sections'] as $index => $section ) {
			$section_keywords = array_slice( array_merge( $lsi_keywords, $related_keywords ), $index * 2, 3 );

			$prompt = "Write a comprehensive section for an article about '{$primary_keyword}'.

{$language_instruction}

SECTION DETAILS:
- Heading: {$section['heading']}
- Level: H{$section['level']}
- Content notes: " . implode( ', ', $section['notes'] ?? [] ) . "

REQUIREMENTS:
- Start with the H{$section['level']} heading
- Write 300-500 words of valuable, informative content
- Naturally incorporate these keywords: " . implode( ', ', $section_keywords ) . "
- Use bullet points or numbered lists where appropriate
- Include practical examples or tips
- Maintain SEO-friendly structure with subheadings if needed
- Use a professional but engaging tone

SUBSECTIONS:";

			if ( ! empty( $section['subsections'] ) ) {
				foreach ( $section['subsections'] as $subsection ) {
					$prompt .= "\n- {$subsection['heading']} (H{$subsection['level']}): " . implode( ', ', $subsection['notes'] ?? [] );
				}
			}

			$prompt .= "\n\nReturn only the HTML content without any markdown formatting.";

			$section_content = $this->call_openai_api( $api_key, $prompt );
			
			$sections[] = [
				'heading' => $section['heading'],
				'level'   => $section['level'],
				'content' => $section_content,
			];

			// Add a small delay to avoid rate limiting
			sleep( 1 );
		}

		return $sections;
	}

	/**
	 * Generate FAQ section.
	 *
	 * @param string $api_key OpenAI API key.
	 * @param string $primary_keyword Primary keyword.
	 * @param array  $outline Content outline.
	 * @param array  $keywords Keywords data.
	 * @param string $language Language code.
	 * @return string
	 */
	private function generate_faq( $api_key, $primary_keyword, $outline, $keywords, $language ) {
		if ( empty( $outline['faq'] ) ) {
			return '';
		}

		$language_instruction = $this->get_language_instruction( $language );
		$lsi_keywords = $this->extract_keyword_list( $keywords['lsi'] ?? [] );

		$faq_items = [];
		foreach ( $outline['faq'] as $faq ) {
			$faq_items[] = "Q: {$faq['question']}\nAnswer guidance: {$faq['answer_notes']}";
		}

		$prompt = "Create a comprehensive FAQ section for an article about '{$primary_keyword}'.

{$language_instruction}

FAQ ITEMS TO ANSWER:
" . implode( "\n\n", $faq_items ) . "

REQUIREMENTS:
- Start with an H2 heading 'Frequently Asked Questions'
- Format each Q&A with proper HTML structure
- Each answer should be 50-100 words
- Naturally incorporate these LSI keywords: " . implode( ', ', array_slice( $lsi_keywords, 0, 5 ) ) . "
- Use schema-friendly markup for FAQ
- Provide helpful, accurate answers

Return only the HTML content without any markdown formatting.";

		return $this->call_openai_api( $api_key, $prompt );
	}

	/**
	 * Generate conclusion section.
	 *
	 * @param string $api_key OpenAI API key.
	 * @param string $primary_keyword Primary keyword.
	 * @param array  $outline Content outline.
	 * @param array  $keywords Keywords data.
	 * @param string $language Language code.
	 * @return string
	 */
	private function generate_conclusion( $api_key, $primary_keyword, $outline, $keywords, $language ) {
		$language_instruction = $this->get_language_instruction( $language );

		$prompt = "Write a compelling conclusion for an article about '{$primary_keyword}'.

{$language_instruction}

REQUIREMENTS:
- Summarize the key points covered in the article
- Reinforce the value provided to the reader
- Include the primary keyword: {$primary_keyword}
- End with a call-to-action or next steps
- Length: 100-150 words
- Use an encouraging and actionable tone

CONCLUSION NOTES: " . implode( ', ', $outline['conclusion']['notes'] ?? [] ) . "

Return only the HTML content without any markdown formatting.";

		return $this->call_openai_api( $api_key, $prompt );
	}

	/**
	 * Compile full HTML content.
	 *
	 * @param array $content Content sections.
	 * @return string
	 */
	private function compile_full_content( $content ) {
		$html = '';

		// Add introduction
		if ( ! empty( $content['introduction'] ) ) {
			$html .= $content['introduction'] . "\n\n";
		}

		// Add main sections
		foreach ( $content['sections'] as $section ) {
			$html .= $section['content'] . "\n\n";
		}

		// Add FAQ
		if ( ! empty( $content['faq'] ) ) {
			$html .= $content['faq'] . "\n\n";
		}

		// Add conclusion
		if ( ! empty( $content['conclusion'] ) ) {
			$html .= $content['conclusion'] . "\n\n";
		}

		return trim( $html );
	}

	/**
	 * Get language-specific instruction.
	 *
	 * @param string $language Language code.
	 * @return string
	 */
	private function get_language_instruction( $language ) {
		$instructions = [
			'en' => 'Write in English with natural, engaging language.',
			'es' => 'Escribe en español con un lenguaje natural y atractivo.',
			'fr' => 'Écrivez en français avec un langage naturel et engageant.',
			'de' => 'Schreiben Sie auf Deutsch mit natürlicher, ansprechender Sprache.',
			'it' => 'Scrivi in italiano con un linguaggio naturale e coinvolgente.',
			'pt' => 'Escreva em português com linguagem natural e envolvente.',
			'th' => 'เขียนเป็นภาษาไทยด้วยภาษาที่เป็นธรรมชาติและน่าสนใจ ใช้โทนที่เป็นกันเองแต่ดูน่าเชื่อถือ เหมาะกับผู้อ่านไทย',
			'ja' => '自然で魅力的な日本語で書いてください。',
			'ko' => '자연스럽고 매력적인 한국어로 작성하세요.',
			'zh' => '用自然、引人入胜的中文写作。',
		];

		return $instructions[ $language ] ?? $instructions['en'];
	}

	/**
	 * Extract keyword list from keyword data.
	 *
	 * @param array $keyword_data Keyword data.
	 * @return array
	 */
	private function extract_keyword_list( $keyword_data ) {
		if ( empty( $keyword_data ) ) {
			return [];
		}

		$keywords = [];
		foreach ( $keyword_data as $kw ) {
			if ( is_array( $kw ) && isset( $kw['keyword'] ) ) {
				$keywords[] = $kw['keyword'];
			} elseif ( is_string( $kw ) ) {
				$keywords[] = $kw;
			}
		}

		return $keywords;
	}

	/**
	 * Call OpenAI API using cURL (following user's preferred pattern).
	 *
	 * @param string $api_key API key.
	 * @param string $prompt Prompt.
	 * @return string
	 */
	private function call_openai_api( $api_key, $prompt ) {
		$payload = [
			"model" => "gpt-4-turbo",
			"messages" => [
				["role" => "system", "content" => "You are an expert SEO content writer. Write high-quality, engaging content that ranks well in search engines."],
				["role" => "user", "content" => $prompt],
			],
			"temperature" => 0.65,
			"max_tokens" => 2000
		];

		$ch = curl_init('https://api.openai.com/v1/chat/completions');
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Content-Type: application/json',
			'Authorization: Bearer ' . $api_key,
		]);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);
		
		$response = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		if ($response === false) {
			throw new \Exception('cURL error: Failed to connect to OpenAI API');
		}

		if ($http_code !== 200) {
			throw new \Exception('OpenAI API error: HTTP ' . $http_code);
		}

		$data = json_decode($response, true);

		if (empty($data['choices'][0]['message']['content'])) {
			throw new \Exception('Empty response from OpenAI API');
		}

		return trim($data['choices'][0]['message']['content']);
	}

	/**
	 * Generate content using simplified approach (like user's example).
	 *
	 * @param string $keyword Primary keyword.
	 * @param string $outline Content outline as string.
	 * @param array  $additional_keywords Additional keywords.
	 * @param string $language Language code.
	 * @return string
	 */
	public function generate_simple_content( $keyword, $outline, $additional_keywords = [], $language = 'th' ) {
		$api_key = get_option( 'smart_seo_openai_api_key', '' );
		
		if ( empty( $api_key ) ) {
			throw new \Exception( 'OpenAI API key is required for content generation.' );
		}

		// Build additional keywords string
		$extra_keywords = '';
		if ( ! empty( $additional_keywords ) ) {
			$extra_keywords = '- แทรกคีย์เวิร์ดเสริม: "' . implode( '", "', $additional_keywords ) . '"';
		}

		$language_instruction = $this->get_language_instruction( $language );

		$prompt = <<<EOP
คุณคือนักเขียนบทความ SEO ภาษาไทยระดับมืออาชีพ

เขียนบทความความยาว 1000 คำ เพื่อโปรโมตคำว่า "$keyword" โดยใช้หัวข้อดังนี้:

$outline

รายละเอียดที่ต้องมี:
- ใช้คำว่า "$keyword" อย่างเป็นธรรมชาติใน Title, H1, และเนื้อหา
$extra_keywords
- ใช้โทนภาษากึ่งเป็นกันเอง แต่ดูน่าเชื่อถือ เหมาะกับผู้อ่านไทย
- จบบทความด้วย Call to Action ชัดเจน

ผลลัพธ์ให้อยู่ในรูปแบบ HTML พร้อมใช้งาน
EOP;

		return $this->call_openai_api( $api_key, $prompt );
	}
}