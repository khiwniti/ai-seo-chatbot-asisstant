<?php
/**
 * Outline Generator Agent.
 *
 * @since      1.0.0
 * @package    SmartSeo
 * @subpackage SmartSeoPro\ContentGenerator\Agents
 * @author     Smart SEO Team <support@smartseo.dev>
 */

namespace RankMathPro\ContentGenerator\Agents;

defined( 'ABSPATH' ) || exit;

/**
 * Outline_Generator class.
 */
class Outline_Generator {

	/**
	 * Generate SEO-optimized content outline.
	 *
	 * @param string $primary_keyword Primary keyword.
	 * @param array  $keywords All keywords data.
	 * @param string $content_type Content type (blog_post, product_page, etc.).
	 * @param string $language Language code.
	 * @return array
	 */
	public function generate_outline( $primary_keyword, $keywords, $content_type = 'blog_post', $language = 'en' ) {
		$openai_api_key = get_option( 'smart_seo_openai_api_key', '' );

		if ( empty( $openai_api_key ) ) {
			throw new \Exception( 'OpenAI API key is required for outline generation.' );
		}

		$prompt = $this->build_outline_prompt( $primary_keyword, $keywords, $content_type, $language );
		$response = $this->call_openai_api( $openai_api_key, $prompt );

		if ( empty( $response ) ) {
			throw new \Exception( 'Failed to generate outline from OpenAI.' );
		}

		return $this->parse_outline_response( $response, $primary_keyword );
	}

	/**
	 * Build the prompt for outline generation.
	 *
	 * @param string $primary_keyword Primary keyword.
	 * @param array  $keywords All keywords data.
	 * @param string $content_type Content type.
	 * @param string $language Language code.
	 * @return string
	 */
	private function build_outline_prompt( $primary_keyword, $keywords, $content_type, $language ) {
		$lsi_keywords = $this->extract_keyword_list( $keywords['lsi'] ?? [] );
		$related_keywords = $this->extract_keyword_list( $keywords['related'] ?? [] );
		$long_tail_keywords = $this->extract_keyword_list( $keywords['long_tail'] ?? [] );

		$language_instruction = $this->get_language_instruction( $language );
		$content_type_instruction = $this->get_content_type_instruction( $content_type );

		$prompt = "You are an expert SEO content strategist. Create a comprehensive, SEO-optimized outline for a {$content_type} targeting the primary keyword: '{$primary_keyword}'.

{$language_instruction}

{$content_type_instruction}

KEYWORDS TO INCORPORATE:
- Primary Keyword: {$primary_keyword}
- LSI Keywords: " . implode( ', ', array_slice( $lsi_keywords, 0, 10 ) ) . "
- Related Keywords: " . implode( ', ', array_slice( $related_keywords, 0, 8 ) ) . "
- Long-tail Keywords: " . implode( ', ', array_slice( $long_tail_keywords, 0, 5 ) ) . "

REQUIREMENTS:
1. Create a compelling H1 title that includes the primary keyword
2. Structure with H2, H3, and H4 headings (minimum 6 H2 sections)
3. Include an introduction and conclusion
4. Naturally incorporate LSI and related keywords in headings
5. Add content notes for each section (2-3 bullet points)
6. Include FAQ section with 5-7 questions
7. Suggest internal linking opportunities
8. Recommend meta description (150-160 characters)

FORMAT YOUR RESPONSE AS JSON:
{
  \"title\": \"H1 title here\",
  \"meta_description\": \"Meta description here\",
  \"introduction\": {
    \"heading\": \"Introduction heading\",
    \"notes\": [\"Content note 1\", \"Content note 2\"]
  },
  \"sections\": [
    {
      \"heading\": \"H2 heading\",
      \"level\": 2,
      \"notes\": [\"Content note 1\", \"Content note 2\"],
      \"subsections\": [
        {
          \"heading\": \"H3 heading\",
          \"level\": 3,
          \"notes\": [\"Content note 1\"]
        }
      ]
    }
  ],
  \"faq\": [
    {
      \"question\": \"Question here?\",
      \"answer_notes\": \"Brief answer guidance\"
    }
  ],
  \"conclusion\": {
    \"heading\": \"Conclusion heading\",
    \"notes\": [\"Content note 1\", \"Content note 2\"]
  },
  \"internal_links\": [\"Suggested internal link topic 1\", \"Topic 2\"],
  \"word_count_target\": 1500
}";

		return $prompt;
	}

	/**
	 * Get language-specific instruction.
	 *
	 * @param string $language Language code.
	 * @return string
	 */
	private function get_language_instruction( $language ) {
		$instructions = [
			'en' => 'Write the outline in English.',
			'es' => 'Write the outline in Spanish (Español).',
			'fr' => 'Write the outline in French (Français).',
			'de' => 'Write the outline in German (Deutsch).',
			'it' => 'Write the outline in Italian (Italiano).',
			'pt' => 'Write the outline in Portuguese (Português).',
			'th' => 'Write the outline in Thai (ภาษาไทย). Use natural Thai language and cultural context.',
			'ja' => 'Write the outline in Japanese (日本語).',
			'ko' => 'Write the outline in Korean (한국어).',
			'zh' => 'Write the outline in Chinese (中文).',
		];

		return $instructions[ $language ] ?? $instructions['en'];
	}

	/**
	 * Get content type specific instruction.
	 *
	 * @param string $content_type Content type.
	 * @return string
	 */
	private function get_content_type_instruction( $content_type ) {
		$instructions = [
			'blog_post' => 'This is a blog post that should be informative, engaging, and provide value to readers.',
			'product_page' => 'This is a product page that should focus on benefits, features, and conversion.',
			'service_page' => 'This is a service page that should highlight expertise, process, and value proposition.',
			'how_to_guide' => 'This is a how-to guide that should be step-by-step, actionable, and comprehensive.',
			'comparison' => 'This is a comparison article that should be objective, detailed, and help decision-making.',
			'review' => 'This is a review that should be honest, detailed, and include pros/cons.',
			'news_article' => 'This is a news article that should be timely, factual, and newsworthy.',
		];

		return $instructions[ $content_type ] ?? $instructions['blog_post'];
	}

	/**
	 * Extract keyword list from keyword data.
	 *
	 * @param array $keyword_data Keyword data.
	 * @return array
	 */
	private function extract_keyword_list( $keyword_data ) {
		if ( empty( $keyword_data ) ) {
			return [];
		}

		$keywords = [];
		foreach ( $keyword_data as $kw ) {
			if ( is_array( $kw ) && isset( $kw['keyword'] ) ) {
				$keywords[] = $kw['keyword'];
			} elseif ( is_string( $kw ) ) {
				$keywords[] = $kw;
			}
		}

		return $keywords;
	}

	/**
	 * Call OpenAI API using cURL.
	 *
	 * @param string $api_key API key.
	 * @param string $prompt Prompt.
	 * @return string
	 */
	private function call_openai_api( $api_key, $prompt ) {
		$payload = [
			"model" => "gpt-4-turbo",
			"messages" => [
				["role" => "system", "content" => "You are an expert SEO content strategist and outline creator. Always respond with valid JSON format."],
				["role" => "user", "content" => $prompt],
			],
			"temperature" => 0.7,
			"max_tokens" => 2000
		];

		$ch = curl_init('https://api.openai.com/v1/chat/completions');
		curl_setopt($ch, CURLOPT_HTTPHEADER, [
			'Content-Type: application/json',
			'Authorization: Bearer ' . $api_key,
		]);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_TIMEOUT, 60);
		
		$response = curl_exec($ch);
		$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);

		if ($response === false) {
			throw new \Exception('cURL error: Failed to connect to OpenAI API');
		}

		if ($http_code !== 200) {
			throw new \Exception('OpenAI API error: HTTP ' . $http_code);
		}

		$data = json_decode($response, true);

		if (empty($data['choices'][0]['message']['content'])) {
			throw new \Exception('Empty response from OpenAI API');
		}

		return $data['choices'][0]['message']['content'];
	}

	/**
	 * Parse outline response from OpenAI.
	 *
	 * @param string $response API response.
	 * @param string $primary_keyword Primary keyword.
	 * @return array
	 */
	private function parse_outline_response( $response, $primary_keyword ) {
		// Clean the response to extract JSON
		$response = trim( $response );
		
		// Remove markdown code blocks if present
		$response = preg_replace( '/^```json\s*/', '', $response );
		$response = preg_replace( '/\s*```$/', '', $response );

		$outline = json_decode( $response, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			// Fallback: try to extract JSON from the response
			preg_match( '/\{.*\}/s', $response, $matches );
			if ( ! empty( $matches[0] ) ) {
				$outline = json_decode( $matches[0], true );
			}
		}

		if ( empty( $outline ) || json_last_error() !== JSON_ERROR_NONE ) {
			throw new \Exception( 'Failed to parse outline JSON response.' );
		}

		// Validate and enhance the outline
		$outline = $this->validate_and_enhance_outline( $outline, $primary_keyword );

		return $outline;
	}

	/**
	 * Validate and enhance the outline structure.
	 *
	 * @param array  $outline Parsed outline.
	 * @param string $primary_keyword Primary keyword.
	 * @return array
	 */
	private function validate_and_enhance_outline( $outline, $primary_keyword ) {
		// Ensure required fields exist
		$outline['title'] = $outline['title'] ?? "Complete Guide to {$primary_keyword}";
		$outline['meta_description'] = $outline['meta_description'] ?? "Learn everything about {$primary_keyword} in this comprehensive guide.";
		$outline['word_count_target'] = $outline['word_count_target'] ?? 1500;
		$outline['sections'] = $outline['sections'] ?? [];
		$outline['faq'] = $outline['faq'] ?? [];
		$outline['internal_links'] = $outline['internal_links'] ?? [];

		// Add estimated reading time
		$outline['estimated_reading_time'] = ceil( $outline['word_count_target'] / 200 );

		// Add SEO score estimation
		$outline['seo_score'] = $this->calculate_seo_score( $outline, $primary_keyword );

		return $outline;
	}

	/**
	 * Calculate basic SEO score for the outline.
	 *
	 * @param array  $outline Outline data.
	 * @param string $primary_keyword Primary keyword.
	 * @return int
	 */
	private function calculate_seo_score( $outline, $primary_keyword ) {
		$score = 0;

		// Check if primary keyword is in title
		if ( stripos( $outline['title'], $primary_keyword ) !== false ) {
			$score += 20;
		}

		// Check if meta description is appropriate length
		$meta_length = strlen( $outline['meta_description'] );
		if ( $meta_length >= 150 && $meta_length <= 160 ) {
			$score += 15;
		}

		// Check number of sections
		$section_count = count( $outline['sections'] );
		if ( $section_count >= 6 ) {
			$score += 20;
		} elseif ( $section_count >= 4 ) {
			$score += 15;
		}

		// Check if FAQ section exists
		if ( ! empty( $outline['faq'] ) && count( $outline['faq'] ) >= 5 ) {
			$score += 15;
		}

		// Check word count target
		if ( $outline['word_count_target'] >= 1000 ) {
			$score += 15;
		}

		// Check internal links suggestions
		if ( ! empty( $outline['internal_links'] ) ) {
			$score += 15;
		}

		return min( $score, 100 );
	}
}