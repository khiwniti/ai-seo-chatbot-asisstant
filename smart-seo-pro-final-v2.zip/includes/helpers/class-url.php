<?php
/**
 * URL helper.
 *
 * @package SmartSeoPro
 */

namespace RankMath\Helpers;

/**
 * URL helper class.
 */
class Url {

	/**
	 * Get current URL.
	 *
	 * @return string
	 */
	public static function get_current_url() {
		if ( ! isset( $_SERVER['HTTP_HOST'] ) || ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return '';
		}

		$protocol = isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
		return $protocol . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
	}

	/**
	 * Get domain from URL.
	 *
	 * @param string $url URL to parse.
	 * @return string
	 */
	public static function get_domain( $url ) {
		$parsed = parse_url( $url );
		return isset( $parsed['host'] ) ? $parsed['host'] : '';
	}

	/**
	 * Check if URL is valid.
	 *
	 * @param string $url URL to validate.
	 * @return bool
	 */
	public static function is_valid( $url ) {
		return filter_var( $url, FILTER_VALIDATE_URL ) !== false;
	}

	/**
	 * Add query args to URL.
	 *
	 * @param array  $args Query arguments.
	 * @param string $url  Base URL.
	 * @return string
	 */
	public static function add_query_arg( $args, $url = '' ) {
		if ( function_exists( 'add_query_arg' ) ) {
			return add_query_arg( $args, $url );
		}

		if ( empty( $url ) ) {
			$url = self::get_current_url();
		}

		$parsed = parse_url( $url );
		$query  = isset( $parsed['query'] ) ? $parsed['query'] : '';
		
		parse_str( $query, $existing_args );
		$args = array_merge( $existing_args, $args );

		$query_string = http_build_query( $args );
		
		$base_url = $parsed['scheme'] . '://' . $parsed['host'];
		if ( isset( $parsed['port'] ) ) {
			$base_url .= ':' . $parsed['port'];
		}
		if ( isset( $parsed['path'] ) ) {
			$base_url .= $parsed['path'];
		}

		return $base_url . ( $query_string ? '?' . $query_string : '' );
	}

	/**
	 * Remove query args from URL.
	 *
	 * @param array  $args Query arguments to remove.
	 * @param string $url  Base URL.
	 * @return string
	 */
	public static function remove_query_arg( $args, $url = '' ) {
		if ( function_exists( 'remove_query_arg' ) ) {
			return remove_query_arg( $args, $url );
		}

		if ( empty( $url ) ) {
			$url = self::get_current_url();
		}

		$parsed = parse_url( $url );
		$query  = isset( $parsed['query'] ) ? $parsed['query'] : '';
		
		parse_str( $query, $existing_args );
		
		foreach ( (array) $args as $arg ) {
			unset( $existing_args[ $arg ] );
		}

		$query_string = http_build_query( $existing_args );
		
		$base_url = $parsed['scheme'] . '://' . $parsed['host'];
		if ( isset( $parsed['port'] ) ) {
			$base_url .= ':' . $parsed['port'];
		}
		if ( isset( $parsed['path'] ) ) {
			$base_url .= $parsed['path'];
		}

		return $base_url . ( $query_string ? '?' . $query_string : '' );
	}
}