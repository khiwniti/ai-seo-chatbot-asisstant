# Smart SEO Pro (formerly AI SEO Chatbot Assistant)

**Important:** This plugin is an add-on for the "Rank Math SEO" plugin and requires "Rank Math SEO" to be installed and activated on your WordPress site to function correctly.

## Description

(User to add a detailed description of the plugin's features here)

## Requirements

*   WordPress (Version compatible with Rank Math SEO)
*   **Rank Math SEO plugin installed and activated.**

## Installation

1.  Ensure "Rank Math SEO" is installed and activated.
2.  Upload the 'smart-seo-pro.zip' file through the WordPress admin panel (Plugins > Add New > Upload Plugin).
3.  Activate "Smart SEO Pro".

## Troubleshooting

*   **Error: Class 'RankMath\Helpers\Param' not found (or similar Rank Math class errors):** This means "Rank Math SEO" is not active. Please install and activate "Rank Math SEO".

