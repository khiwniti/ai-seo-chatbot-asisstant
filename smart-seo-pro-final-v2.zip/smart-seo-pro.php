<?php // @codingStandardsIgnoreLine
/**
 * Smart SEO SEO PRO Plugin.
 *
 * @package      SMART_SEO
 * @copyright    Copyright (C) 2018-2020, Smart SEO - support@smartseo.dev
 * @link         https://smartseo.dev
 * @since        2.0.0
 *
 * @wordpress-plugin
 * Plugin Name:       Smart SEO SEO PRO
 * Version:           3.0.81
 * Plugin URI:        https://smartseo.dev/wordpress/plugin/seo-suite/
 * Description:       Super-charge your website’s SEO with the Smart SEO PRO options like Site Analytics, SEO Performance, Custom Schema Templates, News/Video Sitemaps, etc.
 * Author:            Smart SEO SEO
 * Author URI:        https://smartseo.dev/?utm_source=Plugin&utm_medium=Readme%20Author%20URI&utm_campaign=WP
 * License:           GPL-3.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       smart-seo-pro
 * Domain Path:       /languages
 */

defined( 'ABSPATH' ) || exit;

// Smart SEO Pro - Completely standalone, no dependencies

/**
 * SmartSeoPro class.
 *
 * @class The class that holds the entire plugin.
 */
final class SmartSeoPro {

	/**
	 * Plugin version
	 *
	 * @var string
	 */
	public $version = '3.0.81';

	/**
	 * Holds various class instances
	 *
	 * @var array
	 */
	private $container = [];

	/**
	 * Holds messages.
	 *
	 * @var array
	 */
	private $messages = [];

	// No dependencies required - standalone plugin

	/**
	 * The single instance of the class
	 *
	 * @var SmartSeo
	 */
	protected static $instance = null;

	/**
	 * Main SmartSeoPro instance.
	 *
	 * Ensure only one instance is loaded or can be loaded.
	 *
	 * @see smart_seo_pro()
	 * @return SmartSeoPro
	 */
	public static function get() {
		if ( is_null( self::$instance ) && ! ( self::$instance instanceof SmartSeoPro ) ) {
			self::$instance = new SmartSeoPro();
		}
		return self::$instance;
	}

	/**
	 * Class constructor.
	 */
	private function __construct() {
		if ( ! $this->are_requirements_met() ) {
			return;
		}

		$this->define_constants();
		$this->includes();
		new \RankMathPro\Installer();

		add_action( 'init', [ $this, 'localization_setup' ], 1 );
		
		// Initialize immediately - no dependencies required
		$this->setup();
	}

	/**
	 * Instantiate the plugin.
	 */
	public function setup() {
		// Instantiate classes.
		$this->instantiate();

		// Initialize the action hooks.
		$this->init_actions();

		// Loaded action.
		do_action( 'smart_seo_pro/loaded' );
	}

	/**
	 * Check that the WordPress and PHP setup meets the plugin requirements.
	 *
	 * @return bool
	 */
	private function are_requirements_met() {
		// Basic WordPress and PHP requirements only
		if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
			$this->messages[] = esc_html__( 'Smart SEO Pro requires PHP 7.4 or higher.', 'smart-seo-pro' );
		}

		if ( version_compare( get_bloginfo( 'version' ), '5.0', '<' ) ) {
			$this->messages[] = esc_html__( 'Smart SEO Pro requires WordPress 5.0 or higher.', 'smart-seo-pro' );
		}

		if ( ! empty( $this->messages ) ) {
			add_action( 'admin_notices', [ $this, 'activation_error' ] );
			return false;
		}

		return true;
	}

	/**
	 * Plugin activation notice.
	 */
	public function activation_error() {
		?>
		<div class="notice notice-error">
			<p>
				<?php echo join( '<br>', $this->messages ); // phpcs:ignore ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Define the plugin constants.
	 */
	private function define_constants() {
		define( 'SMART_SEO_PRO_VERSION', $this->version );
		define( 'SMART_SEO_PRO_FILE', __FILE__ );
		define( 'SMART_SEO_PRO_PATH', dirname( SMART_SEO_PRO_FILE ) . '/' );
		define( 'SMART_SEO_PRO_URL', plugins_url( '', SMART_SEO_PRO_FILE ) . '/' );
		
		// Compatibility constants
		if ( ! defined( 'RANK_MATH_PRO_FILE' ) ) {
			define( 'RANK_MATH_PRO_FILE', SMART_SEO_PRO_FILE );
		}
		if ( ! defined( 'RANK_MATH_PRO_URL' ) ) {
			define( 'RANK_MATH_PRO_URL', SMART_SEO_PRO_URL );
		}
		if ( ! defined( 'SMART_SEO_VERSION' ) ) {
			define( 'SMART_SEO_VERSION', '1.0.0' );
		}
	}

	/**
	 * Include the required files.
	 */
	private function includes() {
		include dirname( __FILE__ ) . '/vendor/autoload.php';
		
		// Include traits
		include dirname( __FILE__ ) . '/includes/traits/class-hooker.php';
		include dirname( __FILE__ ) . '/includes/traits/class-ajax.php';
		include dirname( __FILE__ ) . '/includes/traits/class-meta.php';
		include dirname( __FILE__ ) . '/includes/traits/class-cache.php';
		include dirname( __FILE__ ) . '/includes/traits/class-shortcode.php';
		
		// Include helper classes
		include dirname( __FILE__ ) . '/includes/class-helper.php';
		include dirname( __FILE__ ) . '/includes/helpers/class-arr.php';
		include dirname( __FILE__ ) . '/includes/helpers/class-str.php';
		include dirname( __FILE__ ) . '/includes/helpers/class-url.php';
		
		// Create compatibility functions for missing rank_math dependencies
		if ( ! function_exists( 'rank_math' ) ) {
			function rank_math() {
				$obj = new stdClass();
				$obj->version = '1.0.0';
				$obj->settings = new stdClass();
				$obj->settings->all_raw = function() { return []; };
				return $obj;
			}
		}
		
		if ( ! function_exists( 'rank_math_pro' ) ) {
			function rank_math_pro() {
				$obj = new stdClass();
				$obj->version = '3.0.81';
				return $obj;
			}
		}
	}

	/**
	 * Instantiate classes.
	 */
	private function instantiate() {
		new \RankMathPro\Modules();
		$this->load_3rd_party();
		$this->init_content_generator();
	}

	/**
	 * Load 3rd party modules.
	 */
	private function load_3rd_party() {

		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			new \RankMathPro\Elementor\Elementor();
		}

		add_action(
			'after_setup_theme',
			function() {
				if ( defined( 'ET_CORE' ) ) {
					new \RankMathPro\Divi\Divi();
				}
			},
			11
		);
	}

	/**
	 * Initialize Content Generator module.
	 */
	private function init_content_generator() {
		if ( ! class_exists( '\RankMathPro\ContentGenerator\Content_Generator' ) ) {
			require_once SMART_SEO_PRO_PATH . 'includes/modules/content-generator/class-content-generator.php';
			require_once SMART_SEO_PRO_PATH . 'includes/modules/content-generator/agents/class-keyword-finder.php';
			require_once SMART_SEO_PRO_PATH . 'includes/modules/content-generator/agents/class-outline-generator.php';
			require_once SMART_SEO_PRO_PATH . 'includes/modules/content-generator/agents/class-ai-writer.php';
			require_once SMART_SEO_PRO_PATH . 'includes/modules/content-generator/agents/class-optimizer.php';
			require_once SMART_SEO_PRO_PATH . 'includes/modules/content-generator/agents/class-media-generator.php';
			require_once SMART_SEO_PRO_PATH . 'includes/modules/content-generator/agents/class-publisher.php';
		}

		// Initialize the content generator
		new \RankMathPro\ContentGenerator\Content_Generator();
	}

	/**
	 * Initialize WordPress action hooks.
	 */
	private function init_actions() {
		if ( is_admin() ) {
			add_action( 'admin_init', [ $this, 'init_admin' ], 15 );
		}

		add_action( 'rest_api_init', [ $this, 'init_rest_api' ] );
		add_action( 'after_setup_theme', [ $this, 'init' ], 11 );
		new \RankMathPro\Common();
		new \RankMathPro\Register_Vars();
	}

	/**
	 * Initialize the admin.
	 */
	public function init_admin() {
		new \RankMathPro\Admin\Admin();
	}

	/**
	 * Load the REST API endpoints.
	 */
	public function init_rest_api() {
		$controllers = [
			new \RankMathPro\Schema\Rest(),
			new \RankMathPro\Analytics\Rest(),
			new \RankMathPro\Rest\Rest(),
		];

		foreach ( $controllers as $controller ) {
			$controller->register_routes();
		}
	}

	/**
	 * Check if a module is active (standalone version - all modules active by default).
	 *
	 * @param string $module Module name.
	 * @param bool   $default Default value.
	 * @return bool
	 */
	private function is_module_active( $module, $default = true ) {
		// Standalone version - all modules are active by default
		return $default;
	}

	/**
	 * Check if WooCommerce is active.
	 *
	 * @return bool
	 */
	private function is_woocommerce_active() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Initialize.
	 */
	public function init() {
		// Standalone version - all modules are active by default
		if ( $this->is_module_active( 'image-seo' ) ) {
			new \RankMathPro\Image_Seo_Pro();
		}

		if ( $this->is_module_active( 'bbpress' ) ) {
			new \RankMathPro\BBPress();
		}

		if ( $this->is_module_active( 'local-seo', false ) ) {
			new \RankMathPro\Local_Seo\Local_Seo();
		}

		if ( $this->is_module_active( 'analytics' ) ) {
			new \RankMathPro\Analytics\Analytics();
		}

		if ( $this->is_woocommerce_active() && $this->is_module_active( 'woocommerce' ) ) {
			new \RankMathPro\WooCommerce();
		}

		if ( $this->is_module_active( '404-monitor' ) ) {
			new \RankMathPro\Monitor_Pro();
		}

		if ( $this->is_module_active( 'redirections' ) ) {
			new \RankMathPro\Redirections\Redirections();
		}

		if ( $this->is_module_active( 'seo-analysis' ) ) {
			new \RankMathPro\SEO_Analysis\SEO_Analysis_Pro();
		}

		if ( function_exists( 'acf' ) && $this->is_module_active( 'acf' ) ) {
			new \RankMathPro\ACF\ACF();
		}

		if ( $this->is_module_active( 'content-ai' ) ) {
			new \RankMathPro\Content_AI();
		}

		new \RankMathPro\Plugin_Update\Plugin_Update();
		new \RankMathPro\Thumbnail_Overlays();
	}

	/**
	 * Initialize plugin for localization.
	 *
	 * Note: the first-loaded translation file overrides any following ones if the same translation is present.
	 *
	 * Locales found in:
	 *     - WP_LANG_DIR/rank-math/rank-math-LOCALE.mo
	 *     - WP_LANG_DIR/plugins/rank-math-LOCALE.mo
	 */
	public function localization_setup() {
		$locale = is_admin() && function_exists( 'get_user_locale' ) ? get_user_locale() : get_locale();
		$locale = apply_filters( 'plugin_locale', $locale, 'smart-seo-pro' ); // phpcs:ignore

		unload_textdomain( 'smart-seo-pro' );
		if ( false === load_textdomain( 'smart-seo-pro', WP_LANG_DIR . '/plugins/seo-by-smart-seo-pro-' . $locale . '.mo' ) ) {
			load_textdomain( 'smart-seo-pro', WP_LANG_DIR . '/seo-by-rank-math/seo-by-smart-seo-pro-' . $locale . '.mo' );
		}

		load_plugin_textdomain( 'smart-seo-pro', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}

	// All dependency checking methods removed - plugin is now completely standalone

	// License activation methods removed - no licensing required
}

/**
 * Returns the main instance of SmartSeoPro to prevent the need to use globals.
 *
 * @return SmartSeoPro
 */
function smart_seo_pro() {
	return SmartSeoPro::get();
}

// Start it.
smart_seo_pro();
